# Workflow — step-by-step interaction

This is the sequence Claude Code follows when `extract-crosstabs` is invoked. Each step is written as an instruction.

---

## Step 1 — Receive the raw data file

Ask the analyst:

> "Please share the raw survey data file. I support:
> - `.sav` (SPSS) — metadata is read automatically
> - `.csv` or `.xlsx` — you'll need to share a codebook alongside
>
> Tell me the file path or upload it."

Accept a single file. If multiple files are offered (e.g., a study split across waves), process the first one and ask whether the analyst wants others processed separately or combined.

Do not proceed until a valid file is provided.

---

## Step 2 — Load and inspect

Run `scripts/load_and_inspect.py` against the file.

For `.sav` files: the script uses `pyreadstat` to extract variable names, labels, value labels, and measurement levels. These become the proposed codebook.

For `.csv` or `.xlsx` files: the script reads the header row and a sample of values but cannot infer labels or value codes. It asks the analyst for a codebook CSV (see `reference/codebook-schema.md` for the format). If no codebook is supplied, the skill cannot proceed — state this clearly and stop.

The inspection returns a structured summary:

- File path, format, row count, column count
- Sample of rows (first 5, anonymised)
- Proposed codebook (from .sav metadata or analyst-supplied CSV)
- Detected screener variables (heuristic: variables named `S1`, `S2`, `screen*`, `qual*`, `qualified*`)
- Detected weight variables (heuristic: variables named `weight`, `wt`, `w_*`)

---

## Step 3 — Confirm the codebook

Present the codebook to the analyst as a readable summary. Example:

> "Here's the codebook I read from the file. Please confirm or correct before we proceed:
>
> **Variables detected: 87**
>
> **Screener variables:**
> - `S1_qualified` (values: 1=Yes, 2=No) — will be used to filter to qualified respondents
> - `S2_age_group` (values: 1=18-24, 2=25-34, 3=35-44, 4=45-54, 5=55+)
> - `S3_market` (values: 1=UAE, 2=KSA)
>
> **Profile variables (suitable as banner cuts):**
> - `D1_gender` (values: 1=Male, 2=Female)
> - `D2_employment` (values: 1=Full-time, 2=Part-time, 3=Self-employed, ...)
> - ...
>
> **Question variables (sample):**
> - `Q1_awareness` — single-response (values: 1=Top of mind, 2=Unaided, 3=Aided, 4=Not aware)
> - `Q2a-Q2e_brands_used` — multi-response (5 binary columns for each brand)
> - `Q3_satisfaction` — scale 1-10
> - `Q4_rank1-Q4_rank3` — ranked (3 rank positions)
> - `Q5_frequency_per_month` — numeric open
> - ...
>
> **Weight variables:**
> - `weight_final` detected
>
> Confirm, correct, or point to gaps. If a variable's question type is wrong, tell me what it should be."

Wait for explicit confirmation. Do not proceed on uncertainty.

If the analyst corrects anything (wrong question type, misread value codes, missing variables), update the codebook and re-display for re-confirmation.

---

## Step 4 — Configure the tabulation

This step is broken into sub-steps. Ask them in order.

### 4a — Banner variables

> "Which variables should form the banner? I'll show them as columns in the crosstab — typically demographics and segments."

Analyst lists variables. For each, confirm:

- The variable name and its label
- Whether to include all values or a subset (e.g., "Top 5 markets only")
- The order of values (use codebook order by default)

Build the banner plan: list of (banner_group_name, banner_values_with_codes).

Always include "Total" as the first banner group (all qualified respondents, no filter).

### 4b — Question variables

> "Which questions should be tabulated? You can provide a list, or say 'all questions' to tabulate every non-screener, non-banner variable."

If "all," proceed with all variables excluding screeners, banners, and weights.

Confirm the list and their question types from the codebook.

### 4c — Base definition

State the default clearly:

> "The analytical base defaults to **qualified respondents only** — respondents who passed the screener. Screener variables remain available as banner cuts for profiling.
>
> Do any specific questions have conditional bases? For example, 'Q7 was asked only to respondents who said Yes to Q6.' If so, tell me which questions and what the filter is."

Record any conditional bases as expressions the script will evaluate. Example: `Q7: base = (Q6 == 1)`.

### 4d — Weighting

> "Do you want weighted tabulations? If yes:
> - Which variable is the weight?
> - What does the weight represent? (e.g., population weighting to census, design weight correcting for sample imbalance)
>
> If no, say 'unweighted' and I'll run unweighted tabulations."

Record the weight variable and the weighting scheme description (the description goes in the methodology note).

### 4e — Missing data

For each question that has missing values or refusal codes, ask:

> "Q3 (Satisfaction) has 47 respondents with missing values and 12 with 'Prefer not to say'. How should I handle each:
> - Exclude from base (standard) — base shrinks, percentages reflect those who answered
> - Include as a category (keep as response row) — base stays the same, shows a 'No answer' row
> - Treat as null (don't include in the table but keep the row) — rare; useful when modelling downstream"

Default offered: exclude from base.

Only ask this for questions where missing values actually exist. Skip silently for clean questions.

### 4f — Derived measures (NETs, means, top/bottom boxes)

Auto-generate a defaults list based on question type:

- **Single-response categorical** — no derived measures by default
- **Multi-response** — no derived measures by default (sum is meaningless)
- **Scale** — NET Top 2, NET Bottom 2, Mean
- **Ranked** — Mean rank, "Any mention" (union of all rank positions)
- **Numeric open** — Mean, Median

Present the list:

> "Here are the derived measures I'll generate by default. Edit, add, or remove:
>
> **Q3 (Scale 1-10):**
> - Mean
> - NET Top 2 (9-10)
> - NET Bottom 2 (1-2)
>
> **Q4 (Ranked, 3 positions):**
> - Mean rank
> - Any mention (rank 1, 2, or 3)
>
> **Q5 (Numeric open — frequency per month):**
> - Mean
> - Median
>
> Want to add NET Top 3 on Q3? NET Bottom 3? A custom grouping? Tell me."

Accept custom NETs defined by value codes: e.g., "NET Aware = Top of mind + Unaided + Aided" on Q1.

### 4g — Significance testing (optional)

> "Do you want significance testing in the output? If yes:
> - Test type: z-test for proportions (default for percent rows), t-test for means, or both
> - Confidence level: 90%, 95% (default), or 99%
> - Multiple-comparison correction: yes (Bonferroni) or no
>
> If no, say 'no sig testing' and I'll skip it."

Record the test configuration. Output will include a `sig_markers` column if enabled.

---

## Step 5 — Tabulate

Run `scripts/tabulate.py` with the confirmed configuration passed as a config JSON.

The script:

1. Loads the raw data
2. Applies the qualified-respondent filter
3. Applies weight (if specified)
4. For each question × banner cut combination, computes:
   - The count (weighted or unweighted)
   - The percent (of the relevant base)
   - Any requested derived measures (NETs, means, medians)
5. Runs significance tests if configured
6. Produces a long-format DataFrame in the Path A schema

Example invocation:

```bash
python scripts/tabulate.py \
  --input /path/to/raw_data.sav \
  --codebook /path/to/codebook.csv \
  --config /path/to/tabulation_config.json \
  --output-dir /path/to/output/
```

---

## Step 6 — Generate outputs

The tabulation script writes the flat file. Additionally run `scripts/format_crosstab.py` to produce the human-readable Excel.

Outputs:

1. **Flat long** — `flat_<studyname>_long.csv` + `.xlsx`
2. **Flat wide** — `flat_<studyname>_wide.csv` + `.xlsx`
3. **Formatted crosstab Excel** — `crosstab_<studyname>.xlsx` — traditional layout for human reading

The formatted crosstab Excel is:

- Banner rows at the top with merged group headers
- Base size row beneath the banner
- Questions in column A with response options indented
- NET / Mean / Median rows labelled clearly
- Percentages formatted with `%` symbol
- Significance markers in-cell if enabled (otherwise in the flat file only)

This file is valid input to `flatten-crosstab`, closing the loop.

---

## Step 7 — Generate the methodology note

Mandatory. Writes `methodology_<studyname>.md`. Contains:

- Study identifier and wave (if provided)
- Date of tabulation
- Source file path and row count
- Base definition (qualified respondents; conditional bases listed per question)
- Weighting — whether applied, which variable, description of scheme
- Missing-data treatment — per-question list of decisions
- Derived measures — per-question list
- Significance testing — test type, confidence level, correction (if enabled)
- Codebook — variable list with labels, value codes, question types
- Any analyst notes

The methodology note travels with the flat file. Downstream consumers — including other LLMs — read it alongside the data to know what was done.

---

## Step 8 — Summarise to the analyst

End the run with a clear summary. Example:

> "Done. Outputs in `/path/to/output/`:
>
> - **flat_brand_health_Q3_2025_long.csv** and **.xlsx** — 5,842 rows
> - **flat_brand_health_Q3_2025_wide.csv** and **.xlsx**
> - **crosstab_brand_health_Q3_2025.xlsx** — formatted for reading
> - **methodology_brand_health_Q3_2025.md**
>
> **Tabulation summary:**
> - Base: 1,000 qualified respondents (filtered from 1,247 total)
> - Weighted: yes (`weight_final`, population-weighted to census)
> - Questions tabulated: 42
> - Banner cuts: 12 (Total + Gender + Age + Market + Segment)
> - Derived measures: 24 NETs + 14 Means across scale/numeric questions
> - Significance testing: z-test at 95% confidence, no correction
>
> **Flags:**
> - Q14 has 89 respondents (base_n = 89 after conditional filter). Small cell sizes in some banner cuts — Gender × Female × Q14 has n = 41. Review before reading sig markers on this question.
>
> Want me to walk through the Q14 base, or is this ready for analysis?"

---

## Edge cases

- **Codebook mismatch** — codebook says variable `X` has values 1–5, data contains values 1–7 → flag and ask the analyst.
- **Variable in codebook but missing from data** → flag and skip that variable.
- **Variable in data but missing from codebook** → flag and ask whether to include (and with what label) or skip.
- **Weight variable has zero or negative values** → stop and raise to the analyst.
- **Conditional base produces n < 30** for a question → flag in the methodology note; analyst decides whether to include or drop.
- **All-missing column** → skip with a note.
- **Mixed question types in a grid** (a matrix question where each row is a different type) → ask the analyst to split into separate configs.
