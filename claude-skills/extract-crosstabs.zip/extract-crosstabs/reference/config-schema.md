# Tabulation config schema

The config JSON is produced through the interactive workflow (Step 4). It tells `tabulate.py` exactly what to compute.

---

## Top-level structure

```json
{
  "study_id": "brand_health_Q3_2025",
  "wave": "Q3_2025",
  "base_filter": "S1_qualified == 1",
  "weight_variable": "weight_final",
  "weighting_description": "Population-weighted to census by age and gender.",
  "banners": [ ... ],
  "questions": [ ... ],
  "significance": { ... },
  "output_dir": "./output"
}
```

---

## Fields

### `study_id` (string, required)

Short identifier used in output filenames.

### `wave` (string, optional)

Wave identifier for tracking studies. Included in output filenames if present.

### `base_filter` (string, required)

Python expression evaluated against the raw data. Only rows where this is `True` are included in the analytical base.

Default for most studies: `"S1_qualified == 1"` (or whichever screener flag marks qualified respondents).

### `weight_variable` (string, optional)

Column name of the weight variable. If omitted or `null`, tabulation is unweighted.

### `weighting_description` (string, required if weight_variable is set)

Plain-text description of the weighting scheme. Recorded in the methodology note.

### `banners` (array, required)

List of banner groups. The first is always Total.

```json
"banners": [
  {
    "group_name": "Total",
    "variable": null,
    "values": [{"code": null, "label": "Total"}]
  },
  {
    "group_name": "Gender",
    "variable": "D1_gender",
    "values": [
      {"code": 1, "label": "Male"},
      {"code": 2, "label": "Female"}
    ]
  },
  {
    "group_name": "Age",
    "variable": "S2_age_group",
    "values": [
      {"code": 1, "label": "18-24"},
      {"code": 2, "label": "25-34"},
      {"code": 3, "label": "35-44"},
      {"code": 4, "label": "45-54"},
      {"code": 5, "label": "55+"}
    ]
  }
]
```

### `questions` (array, required)

List of questions to tabulate. Each question has:

```json
{
  "question_id": "Q1",
  "question_text": "Q1. Awareness of Brand X",
  "question_type": "single_response",
  "variable": "Q1_awareness",
  "value_codes": [
    {"code": 1, "label": "Top of mind"},
    {"code": 2, "label": "Unaided"},
    {"code": 3, "label": "Aided"},
    {"code": 4, "label": "Not aware"}
  ],
  "conditional_base": null,
  "missing_handling": "exclude",
  "derived_measures": [
    {"type": "net", "label": "NET Aware", "codes": [1, 2, 3]}
  ]
}
```

Per question-type, specific fields are expected:

#### single_response

- `variable` — column name
- `value_codes` — array of `{code, label}`
- `derived_measures` — optional NETs

#### multi_response

- `variables` — array of column names (one per option)
- `option_labels` — array mapping each variable to a label
- `derived_measures` — optional custom NETs

#### scale

- `variable` — column name
- `scale_min`, `scale_max` — integer bounds
- `derived_measures` — default: Mean + NET Top 2 + NET Bottom 2

#### ranked

- `variables` — array of column names (one per rank position)
- `rank_positions` — array of position numbers (1, 2, 3, ...)
- `value_codes` — codes for the options being ranked
- `derived_measures` — default: Mean rank + Any mention

#### numeric_open

- `variable` — column name
- `bands` — optional: array of `{min, max, label}` for banded frequency
- `derived_measures` — default: Mean + Median
- `filter` — optional Python expression for outlier exclusion (e.g., `"value <= 100"`)

### `significance` (object, optional)

```json
"significance": {
  "enabled": true,
  "test_type": "z_proportion",
  "confidence_level": 0.95,
  "correction": "none"
}
```

- `test_type` — `"z_proportion"`, `"t_mean"`, or `"both"`
- `confidence_level` — `0.90`, `0.95`, or `0.99`
- `correction` — `"none"` or `"bonferroni"`

### `output_dir` (string, required)

Directory for output files.

---

## Derived measure types

```json
// NET: grouping of response codes (scale or single-response)
{"type": "net", "label": "NET Top 2", "codes": [9, 10]}

// Mean: arithmetic mean of scale or numeric values
{"type": "mean", "label": "Mean"}

// Median
{"type": "median", "label": "Median"}

// Any mention: for ranked, respondents who ranked the option anywhere
{"type": "any_mention", "label": "Any mention"}

// Mean rank: for ranked questions
{"type": "mean_rank", "label": "Mean rank"}

// Standard deviation
{"type": "std", "label": "Std Dev"}

// Top box (value = scale_max)
{"type": "top_box", "label": "Top Box"}

// Bottom box (value = scale_min)
{"type": "bottom_box", "label": "Bottom Box"}

// Custom banded distribution for numeric_open
{"type": "band", "label": "1-5", "min": 1, "max": 5}
```

---

## Example complete config

```json
{
  "study_id": "brand_health_Q3_2025",
  "wave": "Q3_2025",
  "base_filter": "S1_qualified == 1",
  "weight_variable": "weight_final",
  "weighting_description": "Population-weighted to 2024 census by age and gender.",
  "banners": [
    {
      "group_name": "Total",
      "variable": null,
      "values": [{"code": null, "label": "Total"}]
    },
    {
      "group_name": "Gender",
      "variable": "D1_gender",
      "values": [
        {"code": 1, "label": "Male"},
        {"code": 2, "label": "Female"}
      ]
    }
  ],
  "questions": [
    {
      "question_id": "Q1",
      "question_text": "Q1. Awareness of Brand X",
      "question_type": "single_response",
      "variable": "Q1_awareness",
      "value_codes": [
        {"code": 1, "label": "Top of mind"},
        {"code": 2, "label": "Unaided"},
        {"code": 3, "label": "Aided"},
        {"code": 4, "label": "Not aware"}
      ],
      "missing_handling": "exclude",
      "derived_measures": [
        {"type": "net", "label": "NET Aware", "codes": [1, 2, 3]}
      ]
    },
    {
      "question_id": "Q3",
      "question_text": "Q3. Satisfaction with Brand X",
      "question_type": "scale",
      "variable": "Q3_satisfaction",
      "scale_min": 1,
      "scale_max": 10,
      "missing_handling": "exclude",
      "derived_measures": [
        {"type": "mean", "label": "Mean"},
        {"type": "net", "label": "NET Top 2", "codes": [9, 10]},
        {"type": "net", "label": "NET Bottom 2", "codes": [1, 2]}
      ]
    }
  ],
  "significance": {
    "enabled": true,
    "test_type": "z_proportion",
    "confidence_level": 0.95,
    "correction": "none"
  },
  "output_dir": "./output"
}
```
