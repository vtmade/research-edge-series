# Codebook schema

When the raw data is in `.csv` or `.xlsx`, the skill requires a separate codebook CSV. `.sav` files carry this metadata internally, so a separate codebook is optional (though recommended for audit).

This document describes the expected codebook format.

---

## File format

- Single CSV file
- UTF-8 encoding
- One row per variable
- Header row required

---

## Required columns

| Column | Type | Description |
|---|---|---|
| `variable` | string | The column name in the raw data file (case-sensitive). |
| `label` | string | Human-readable question text or variable description. |
| `question_type` | string | One of: `single_response`, `multi_response`, `scale`, `ranked`, `numeric_open`, `screener`, `profile`, `weight`, `id`. |
| `value_codes` | string | Semicolon-separated list of `code=label` pairs. Example: `1=Male;2=Female`. Leave blank for `numeric_open`, `weight`, and `id`. |

---

## Optional columns

| Column | Type | Description |
|---|---|---|
| `scale_min` | integer | For scale questions: the minimum value. Example: `1`. |
| `scale_max` | integer | For scale questions: the maximum value. Example: `10`. |
| `multi_response_group` | string | For multi-response: a group name that links the columns belonging to the same question. Example: `brands_used`. |
| `rank_group` | string | For ranked: a group name linking rank-position columns. Example: `brand_preference`. |
| `rank_position` | integer | For ranked: the rank position this column represents. Example: `1` for "most preferred." |
| `conditional_base` | string | Python-evaluable expression describing the base filter. Example: `Q6 == 1`. |
| `notes` | string | Free text. Any caveats the analyst should know. |

---

## Example codebook

```csv
variable,label,question_type,value_codes,scale_min,scale_max,multi_response_group,rank_group,rank_position,conditional_base,notes
respondent_id,Respondent ID,id,,,,,,,,
weight_final,Final post-stratification weight,weight,,,,,,,,
S1_qualified,Passed screener,screener,1=Yes;2=No,,,,,,,Filter base to S1_qualified==1
S2_age_group,Age group,profile,1=18-24;2=25-34;3=35-44;4=45-54;5=55+,,,,,,,
D1_gender,Gender,profile,1=Male;2=Female,,,,,,,
D2_market,Market,profile,1=UAE;2=KSA,,,,,,,
Q1_awareness,Q1. Awareness of Brand X,single_response,1=Top of mind;2=Unaided;3=Aided;4=Not aware,,,,,,,
Q2a_brand_visa,Q2. Visa used in last month,multi_response,0=No;1=Yes,,,brands_used,,,,
Q2b_brand_mc,Q2. Mastercard used in last month,multi_response,0=No;1=Yes,,,brands_used,,,,
Q2c_brand_amex,Q2. Amex used in last month,multi_response,0=No;1=Yes,,,brands_used,,,,
Q3_satisfaction,Q3. Satisfaction with Brand X,scale,,1,10,,,,,
Q4_rank1,Q4. Brand ranked first,ranked,1=Visa;2=Mastercard;3=Amex,,,,brand_preference,1,,
Q4_rank2,Q4. Brand ranked second,ranked,1=Visa;2=Mastercard;3=Amex,,,,brand_preference,2,,
Q4_rank3,Q4. Brand ranked third,ranked,1=Visa;2=Mastercard;3=Amex,,,,brand_preference,3,,
Q5_frequency,Q5. Times used per month,numeric_open,,,,,,,,
Q6_buyer,Q6. Have you purchased in last 3 months,single_response,1=Yes;2=No,,,,,,,
Q7_satisfaction_post,Q7. Satisfaction with post-purchase,scale,,1,10,,,,,Q6 == 1
```

---

## Rules for the codebook

- **Every variable in the raw data file should appear in the codebook.** If a variable is intentionally excluded from tabulation, include it with `question_type = id` or mark it with a note.
- **Multi-response groups:** all columns in the same multi-response question must share the same `multi_response_group` value. The skill uses this to group them into one question block.
- **Ranked groups:** similarly, all rank-position columns must share `rank_group` and have distinct `rank_position` values.
- **Conditional bases:** use standard Python comparison operators (`==`, `!=`, `<`, `<=`, `>`, `>=`, `in`, `not in`). Reference other variables by their exact column name. Example: `Q6 == 1` or `S1_qualified == 1 and S2_age_group in (2, 3, 4)`.
- **Scale bounds:** for scale questions, both `scale_min` and `scale_max` are required. Missing bounds → skill asks the analyst at runtime.

---

## Auto-detection hints

If a codebook is provided but incomplete, the skill will fill gaps via heuristics and ask the analyst to confirm:

- Variables with all values in {0, 1} grouped by name prefix → inferred as a multi-response group
- Variables with integer values in {1–5, 1–7, 1–10} → inferred as scale
- Variables named `weight*` or `wt*` → inferred as weight
- Variables named `S1*`, `S2*`, `screen*`, `qual*` → inferred as screeners

Heuristics are a fallback. A proper codebook is always better.

---

## Generating a codebook from an existing .sav

If the team has a `.sav` file but wants to produce a human-editable codebook (to modify labels, redefine types, or split grid questions into separate questions), the skill can export the `.sav` metadata as a codebook CSV:

```bash
python scripts/load_and_inspect.py --input data.sav --export-codebook codebook.csv
```

The exported codebook follows the schema above and can be edited before feeding back into the tabulation step.
