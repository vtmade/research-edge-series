# Question types and aggregation rules

Every question in a survey dataset falls into one of five types. The aggregation rule depends on the type — treating a ranked question as a single-response will break the analysis.

---

## Single-response categorical

The respondent picks exactly one option from a set.

**Examples:** "Which best describes you?" (employment status), "Which brand do you use most often?"

**Data shape:** One column per question. Each cell holds a single value code.

**Aggregation:**

- For each banner cut: count respondents at each value, divide by the base, multiply by 100.
- Percentages within a question × banner cut sum to 100 (±1 for rounding), unless missing values are included as a category.

**Output rows:** One `response` row per value code. No default derived measures — analyst can request a custom NET if relevant (e.g., "NET Retail = supermarket + convenience store + department store").

---

## Multi-response

The respondent picks all that apply.

**Examples:** "Which of these have you used in the last month?" (select all brands)

**Data shape:** Typically one column per response option, each holding a binary (1 = selected, 0 = not selected). Some datasets use a single column with comma-separated codes — less common, requires pre-processing.

**Aggregation:**

- For each option, count respondents who selected it, divide by the base, multiply by 100.
- Percentages within a question × banner cut can and usually do exceed 100, because each respondent can pick multiple options.

**Output rows:** One `response` row per option. No default derived measures. Analyst can request custom NETs (e.g., "NET Digital banks = digital bank A + digital bank B + digital bank C").

**Important:** downstream validation that checks "percentages sum to 100" must skip multi-response questions. The question text or codebook should flag them.

---

## Scale / Likert

The respondent picks a point on an ordered scale.

**Examples:** Satisfaction 1–10, Agreement 1–5, Likelihood 1–7.

**Data shape:** One column per question. Values are integers within the scale range.

**Aggregation:**

- Full frequency distribution (one `response` row per scale point), as percent of base.
- Mean of the scale (`value_type = mean`).
- Optional NET rows — commonly NET Top 2 (e.g., 9+10 for a 1–10 scale), NET Bottom 2 (1+2), NET Top 3, NET Bottom 3.

**Default derived measures:** Mean + NET Top 2 + NET Bottom 2.

**Custom derived measures:** analyst can define any NET (e.g., "NET Top Box (10)", "NET Detractors (1-6)").

**Standard deviation:** optional; offered when mean is requested.

---

## Ranked

The respondent orders options from most to least preferred (or similar). Usually captured as the top 3 or top 5 ranks.

**Examples:** "Rank these brands from your most to least preferred: Visa, Mastercard, Amex" — captured as 3 columns, one per rank position.

**Data shape:** Typically one column per rank position, each holding the code of the option ranked at that position. Example: `Q4_rank1 = 3` means "ranked option 3 as their most preferred."

**Aggregation:**

- For each option, count how many respondents ranked it in position 1, position 2, position 3, etc. — separate distributions per rank position.
- Mean rank across all positions (weighting each rank equally, or using inverted weighting if requested).
- "Any mention" — proportion of respondents who ranked the option in any position.

**Output rows:** Per option, one row per rank position (e.g., "Visa — Rank 1", "Visa — Rank 2", "Visa — Rank 3", "Visa — Any mention"). Plus a mean rank row if requested.

**Default derived measures:** Mean rank + Any mention.

**Caution:** respondents who didn't rank all positions produce missing values. Treat as exclude from base for the position, not as a zero.

---

## Numeric open

The respondent types a number.

**Examples:** "How many times per month do you use X?" (free-text numeric response), "What is your age?" (if not banded), "Approximate monthly spend."

**Data shape:** One column per question. Values are integers or floats.

**Aggregation:**

- Mean (`value_type = mean`)
- Median (`value_type = median`)
- Optionally: min, max, standard deviation
- Optionally: banded frequency distribution (analyst specifies bands at runtime — e.g., "0, 1-5, 6-10, 11-20, 21+")

**Default derived measures:** Mean + Median.

**Banded distribution:** offered only when analyst requests. If bands are requested, produces `response` rows per band plus the mean/median.

**Outliers:** the skill does not automatically trim outliers. Analyst can specify a filter at runtime (e.g., "exclude values > 100"). Trimming is recorded in the methodology note.

---

## Special cases

### Grid / matrix questions

A single question block where the same scale is asked about multiple attributes (e.g., "Rate brand A, B, C, D on satisfaction 1-10"). Treat each row of the grid as a separate scale question, with the attribute as part of the question text.

### Open-ended text

Not tabulated by this skill. Open-ended text requires qualitative coding first — a separate workflow. Flag and skip.

### Constant-sum questions

Respondents allocate points across options, summing to a fixed total (e.g., 100 points across 5 brands). Treat each allocation column as a numeric-open question. Report mean allocation per option.

### Maxdiff / best-worst

Not directly tabulated by this skill. Requires utility estimation upstream. Flag and direct the analyst to a specialist tool.

---

## How question type is determined

1. **For .sav files** — `pyreadstat` measurement level:
   - `nominal` → likely single-response or multi-response (distinguish by value code count)
   - `ordinal` → likely scale
   - `scale` → likely numeric open
   - But metadata is often imprecise, so analyst confirmation overrides detection.

2. **For .csv / .xlsx files** — the codebook must declare the type in a `question_type` column (see `codebook-schema.md`).

3. **Heuristic fallbacks** when metadata is missing:
   - All values in {0, 1} across multiple related columns → multi-response
   - All values integers in a small range (1–5, 1–7, 1–10) → scale
   - All values integers in a larger range with low frequency at each → numeric open
   - All values strings or irregular integers → single-response categorical

4. **Analyst confirmation is always the final word.** No matter what the skill infers, the analyst signs off before tabulation runs.
