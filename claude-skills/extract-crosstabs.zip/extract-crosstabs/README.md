# extract-crosstabs

A Claude Code skill for generating flat-format crosstabs directly from raw respondent-level survey data (.sav, .csv, .xlsx). Built for analysts who have the source data and want to produce their own crosstabs, fully auditable and LLM-ready.

This skill complements **flatten-crosstab** (Path A). Where flatten-crosstab takes a finished crosstab and reshapes it, extract-crosstabs starts from the raw data and produces the crosstab itself.

---

## Install

Drop the folder into your Claude Code skills directory:

```bash
cp -r extract-crosstabs ~/.claude/skills/
```

---

## Invoke

```
/extract-crosstabs
```

Or say it naturally:

> "tabulate this raw data"
> "generate crosstabs from this SPSS file"
> "cross-cut this dataset by demographics"
> "run tabs on this survey"

---

## What it does

Takes a raw respondent-level file + a codebook (auto-extracted for SPSS, required for CSV/Excel) and produces:

- **Flat file (long + wide)** — CSV + Excel in the same schema as flatten-crosstab
- **Formatted crosstab Excel** — traditional layout for human reading, also valid input to flatten-crosstab
- **Methodology note** — full documentation of every decision made

---

## Workflow

1. You share the raw data file (.sav, .csv, or .xlsx).
2. The skill loads and inspects it — auto-extracting metadata for SPSS, or asking you for a codebook for CSV/Excel.
3. You confirm the codebook (variables, labels, value codes, question types).
4. You configure the tabulation interactively:
   - Which variables are banners
   - Which variables are questions to tabulate
   - Conditional bases (if any)
   - Weighting (yes/no, which variable, scheme description)
   - Missing-data handling (per question)
   - Derived measures (NETs, means, top/bottom boxes — auto-proposed, you edit)
   - Significance testing (optional)
5. Python computes the tabulation deterministically.
6. All outputs are written, plus a methodology note.

---

## What to have ready

- The raw data file
- A codebook if the file is CSV or Excel (see `reference/codebook-schema.md`)
- Clarity on which screener flag identifies qualified respondents
- The weight variable name (if you want weighted tabulations)
- Any conditional base rules for specific questions

---

## Question types supported

- Single-response categorical (radio-button)
- Multi-response (select-all-that-apply)
- Scale / Likert (1–5, 1–7, 1–10)
- Ranked (top-N preferences)
- Numeric open (free-text numeric)

See `reference/question-types.md` for aggregation rules per type.

---

## Non-negotiables

- **Codebook confirmation is required.** Never tabulate on an unconfirmed codebook.
- **Qualified respondents only.** Non-qualified are excluded from the base.
- **Weighting is analyst-driven.** Never applied silently.
- **No imputation.** Missing data is handled by exclude/include/null — not filled in.
- **Python tabulates; the LLM never does.** All counts, percentages, means computed by pandas/scipy.
- **Methodology note is always produced.** No exceptions.

---

## Chain with flatten-crosstab

The formatted crosstab Excel produced by this skill is a valid input to `flatten-crosstab`. This means:

- You can generate a crosstab from raw data (this skill)
- Share the formatted Excel with a non-analyst stakeholder (for human reading)
- Later, anyone else can flatten that Excel back into the long format (via flatten-crosstab) without needing the raw data

The two skills share the same output schema, so the whole system composes cleanly.

---

## Files in this folder

```
extract-crosstabs/
├── SKILL.md                          # Skill trigger + workflow (read by Claude Code)
├── README.md                         # This file
├── reference/
│   ├── workflow.md                   # Step-by-step interaction
│   ├── question-types.md             # Aggregation rules per type
│   ├── codebook-schema.md            # Codebook format for CSV/Excel inputs
│   ├── config-schema.md              # Tabulation config schema
│   └── codebook.example.csv          # Sample codebook
└── scripts/
    ├── load_and_inspect.py           # Reads file, proposes codebook
    ├── tabulate.py                   # Deterministic tabulation engine
    └── format_crosstab.py            # Human-readable Excel writer
```

---

## Limitations (v1)

- Significance testing is z-test for proportions only in v1; t-test for means is a stub. Bonferroni correction not yet implemented.
- Constant-sum questions are treated as numeric-open per column.
- MaxDiff / best-worst not supported — direct the analyst to specialist tools.
- Open-ended text questions not tabulated — requires qualitative coding first.
- Grid / matrix questions need to be split into separate single-column configs.

---

## Feedback

This is a working draft. Test it on real studies; tell me where it broke, with a sanitised sample if possible. The biggest risk surface is codebook extraction from messy SPSS files — especially those with inconsistent value labels or ambiguous measurement levels.
