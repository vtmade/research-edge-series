#!/usr/bin/env python3
"""
load_and_inspect.py

Loads a raw survey data file (.sav, .csv, .xlsx) and returns a structured
summary of its contents for the LLM to present to the analyst.

For .sav files, extracts metadata (labels, value codes, measurement levels)
via pyreadstat. For .csv/.xlsx, requires a codebook CSV to be supplied.

Usage:
    python load_and_inspect.py --input <path> [--codebook <path>] [--export-codebook <path>]
"""

import argparse
import json
import re
import sys
from pathlib import Path

import pandas as pd


SCREENER_PATTERNS = [r"^S\d", r"^screen", r"^qual"]
WEIGHT_PATTERNS = [r"^weight", r"^wt", r"^w_"]
ID_PATTERNS = [r"^id$", r"^respondent_?id", r"^rid$", r"^uuid"]


def matches_any(name: str, patterns: list[str]) -> bool:
    name_lower = name.lower()
    return any(re.search(p, name_lower, re.IGNORECASE) for p in patterns)


def classify_variable(
    var_name: str, values: pd.Series, metadata_type: str | None = None
) -> str:
    """Heuristic classification of a variable's question type."""
    if matches_any(var_name, ID_PATTERNS):
        return "id"
    if matches_any(var_name, WEIGHT_PATTERNS):
        return "weight"
    if matches_any(var_name, SCREENER_PATTERNS):
        return "screener"

    non_null = values.dropna()
    if non_null.empty:
        return "unknown"

    # Check if binary (multi-response likely)
    unique_values = set(non_null.unique())
    if unique_values <= {0, 1, 0.0, 1.0}:
        return "multi_response_candidate"

    # All numeric?
    if pd.api.types.is_numeric_dtype(non_null):
        # Small integer range → scale
        int_values = non_null[non_null.apply(lambda x: float(x).is_integer())]
        if not int_values.empty:
            vmin, vmax = int(int_values.min()), int(int_values.max())
            spread = vmax - vmin
            n_unique = int_values.nunique()
            if spread <= 10 and n_unique <= 11:
                return "scale"
            if spread > 10 and n_unique > 15:
                return "numeric_open"
        else:
            return "numeric_open"

    return "single_response"


def load_sav_file(filepath: str) -> dict:
    """Load a .sav file and return data + metadata."""
    try:
        import pyreadstat
    except ImportError:
        return {
            "error": "pyreadstat is required to read .sav files. Install with: pip install pyreadstat"
        }

    df, meta = pyreadstat.read_sav(filepath)
    return {
        "df": df,
        "variable_labels": meta.column_names_to_labels or {},
        "value_labels": meta.variable_value_labels or {},
        "measurement_levels": meta.variable_measure or {},
        "row_count": len(df),
    }


def load_csv_xlsx(filepath: str) -> dict:
    """Load a .csv or .xlsx file."""
    path = Path(filepath)
    if path.suffix.lower() == ".csv":
        df = pd.read_csv(filepath)
    else:
        df = pd.read_excel(filepath)
    return {
        "df": df,
        "variable_labels": {},
        "value_labels": {},
        "measurement_levels": {},
        "row_count": len(df),
    }


def load_codebook(codebook_path: str) -> pd.DataFrame:
    """Load a codebook CSV."""
    cb = pd.read_csv(codebook_path)
    required = {"variable", "label", "question_type"}
    missing = required - set(cb.columns)
    if missing:
        raise ValueError(f"Codebook missing required columns: {missing}")
    return cb


def parse_value_codes(vc_string) -> list[dict]:
    """Parse '1=Yes;2=No' into [{'code': 1, 'label': 'Yes'}, ...]."""
    if not isinstance(vc_string, str) or not vc_string.strip():
        return []
    out = []
    for pair in vc_string.split(";"):
        pair = pair.strip()
        if "=" not in pair:
            continue
        code, label = pair.split("=", 1)
        code = code.strip()
        label = label.strip()
        try:
            code_typed = int(code)
        except ValueError:
            try:
                code_typed = float(code)
            except ValueError:
                code_typed = code
        out.append({"code": code_typed, "label": label})
    return out


def build_codebook_from_metadata(loaded: dict) -> list[dict]:
    """Build a codebook from .sav metadata + heuristics."""
    df = loaded["df"]
    labels = loaded["variable_labels"]
    value_labels = loaded["value_labels"]
    measure = loaded["measurement_levels"]

    rows = []
    for col in df.columns:
        label = labels.get(col, col)
        vl = value_labels.get(col, {})
        m_level = measure.get(col, "")

        q_type = classify_variable(col, df[col], m_level)
        # Override using measurement level if meaningful
        if m_level == "scale" and q_type in ("single_response", "scale"):
            # pyreadstat "scale" = continuous; usually numeric_open
            q_type = "numeric_open"
        elif m_level == "ordinal" and q_type == "single_response":
            q_type = "scale"

        value_codes = [{"code": k, "label": v} for k, v in vl.items()] if vl else []

        rows.append(
            {
                "variable": col,
                "label": label,
                "question_type": q_type,
                "value_codes": value_codes,
                "sample_values": df[col].dropna().head(5).tolist(),
                "n_unique": df[col].nunique(),
                "n_missing": df[col].isna().sum(),
            }
        )
    return rows


def build_codebook_from_csv(codebook_df: pd.DataFrame, data_df: pd.DataFrame) -> list[dict]:
    """Build a codebook from the analyst-supplied CSV."""
    rows = []
    for _, cb_row in codebook_df.iterrows():
        var = cb_row["variable"]
        value_codes = parse_value_codes(cb_row.get("value_codes", ""))
        row_out = {
            "variable": var,
            "label": cb_row.get("label", var),
            "question_type": cb_row.get("question_type", "unknown"),
            "value_codes": value_codes,
        }
        if var in data_df.columns:
            row_out["sample_values"] = data_df[var].dropna().head(5).tolist()
            row_out["n_unique"] = int(data_df[var].nunique())
            row_out["n_missing"] = int(data_df[var].isna().sum())
        else:
            row_out["warning"] = "Variable in codebook but not in data file"
        # Optional fields
        for opt in [
            "scale_min",
            "scale_max",
            "multi_response_group",
            "rank_group",
            "rank_position",
            "conditional_base",
            "notes",
        ]:
            if opt in cb_row and pd.notna(cb_row[opt]):
                row_out[opt] = cb_row[opt]
        rows.append(row_out)

    # Flag variables in data but not in codebook
    codebook_vars = set(codebook_df["variable"].tolist())
    extra = [c for c in data_df.columns if c not in codebook_vars]
    return rows, extra


def export_codebook(codebook_rows: list[dict], output_path: str):
    """Export a codebook to CSV."""
    out_rows = []
    for r in codebook_rows:
        vc_str = ";".join(f"{v['code']}={v['label']}" for v in r.get("value_codes", []))
        out_rows.append(
            {
                "variable": r["variable"],
                "label": r["label"],
                "question_type": r["question_type"],
                "value_codes": vc_str,
                "scale_min": "",
                "scale_max": "",
                "multi_response_group": "",
                "rank_group": "",
                "rank_position": "",
                "conditional_base": "",
                "notes": "",
            }
        )
    pd.DataFrame(out_rows).to_csv(output_path, index=False, encoding="utf-8-sig")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--codebook", default=None)
    parser.add_argument("--export-codebook", default=None)
    args = parser.parse_args()

    path = Path(args.input)
    if not path.exists():
        print(json.dumps({"error": f"File not found: {args.input}"}))
        sys.exit(1)

    ext = path.suffix.lower()
    if ext == ".sav":
        loaded = load_sav_file(str(path))
        if "error" in loaded:
            print(json.dumps(loaded))
            sys.exit(1)
        codebook = build_codebook_from_metadata(loaded)
        extras = []
    elif ext in (".csv", ".xlsx", ".xls"):
        loaded = load_csv_xlsx(str(path))
        if not args.codebook:
            print(
                json.dumps(
                    {
                        "error": (
                            f"{ext} input requires a codebook. "
                            "Provide --codebook <path> with a CSV matching reference/codebook-schema.md"
                        )
                    }
                )
            )
            sys.exit(1)
        cb_df = load_codebook(args.codebook)
        codebook, extras = build_codebook_from_csv(cb_df, loaded["df"])
    else:
        print(json.dumps({"error": f"Unsupported file type: {ext}"}))
        sys.exit(1)

    if args.export_codebook:
        export_codebook(codebook, args.export_codebook)

    # Build summary
    summary = {
        "file": str(path.absolute()),
        "format": ext,
        "row_count": loaded["row_count"],
        "variable_count": len(codebook),
        "codebook": codebook,
        "extras_not_in_codebook": extras,
        "detected_screeners": [c["variable"] for c in codebook if c.get("question_type") == "screener"],
        "detected_weights": [c["variable"] for c in codebook if c.get("question_type") == "weight"],
        "detected_ids": [c["variable"] for c in codebook if c.get("question_type") == "id"],
    }
    print(json.dumps(summary, indent=2, default=str))


if __name__ == "__main__":
    main()
