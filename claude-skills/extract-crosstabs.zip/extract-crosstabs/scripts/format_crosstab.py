#!/usr/bin/env python3
"""
format_crosstab.py

Converts a flat-format tabulation into a traditional, human-readable crosstab
Excel file. The output is also valid input to the flatten-crosstab skill.

Usage:
    python format_crosstab.py --flat <flat_long.csv> --output <crosstab.xlsx>
"""

import argparse
import sys
from pathlib import Path

import pandas as pd


def build_formatted_crosstab(flat: pd.DataFrame, output_path: Path):
    """Build a traditional crosstab Excel with banner at top and questions in column A."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    ws = wb.active
    ws.title = "Crosstabs"

    # Styles
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill("solid", fgColor="2F5496")
    group_fill = PatternFill("solid", fgColor="D9E2F3")
    question_font = Font(bold=True, size=11)
    indent_align = Alignment(indent=1)
    thin_border = Border(
        left=Side(style="thin", color="CCCCCC"),
        right=Side(style="thin", color="CCCCCC"),
        top=Side(style="thin", color="CCCCCC"),
        bottom=Side(style="thin", color="CCCCCC"),
    )

    # Build banner columns: (banner_group, banner_value) in stable order
    banner_order = (
        flat[["banner_group", "banner_value"]]
        .drop_duplicates()
        .reset_index(drop=True)
    )
    n_banners = len(banner_order)

    # Row 1: banner group (merged across same group)
    ws.cell(row=1, column=1, value="")
    for i, (_, row) in enumerate(banner_order.iterrows(), start=2):
        ws.cell(row=1, column=i, value=row["banner_group"])
        ws.cell(row=1, column=i).font = header_font
        ws.cell(row=1, column=i).fill = header_fill
        ws.cell(row=1, column=i).alignment = Alignment(horizontal="center")

    # Merge same banner groups across columns
    last_group = None
    merge_start = None
    for i, (_, row) in enumerate(banner_order.iterrows(), start=2):
        if row["banner_group"] != last_group:
            if merge_start and i - 1 > merge_start:
                ws.merge_cells(start_row=1, start_column=merge_start, end_row=1, end_column=i - 1)
            merge_start = i
            last_group = row["banner_group"]
    if merge_start and n_banners + 1 > merge_start:
        ws.merge_cells(start_row=1, start_column=merge_start, end_row=1, end_column=n_banners + 1)

    # Row 2: banner value
    ws.cell(row=2, column=1, value="")
    for i, (_, row) in enumerate(banner_order.iterrows(), start=2):
        cell = ws.cell(row=2, column=i, value=row["banner_value"])
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center")

    # Row 3: base n (take first available base per banner cut)
    ws.cell(row=3, column=1, value="Base (n)")
    ws.cell(row=3, column=1).font = Font(italic=True)
    for i, (_, row) in enumerate(banner_order.iterrows(), start=2):
        bg, bv = row["banner_group"], row["banner_value"]
        sub = flat[(flat["banner_group"] == bg) & (flat["banner_value"] == bv)]
        base_n = sub["base_n"].dropna().iloc[0] if not sub["base_n"].dropna().empty else ""
        cell = ws.cell(row=3, column=i, value=f"(n={int(base_n)})" if base_n else "")
        cell.font = Font(italic=True)
        cell.alignment = Alignment(horizontal="center")

    # Row data: iterate over questions × response rows
    current_row = 4
    for qid, q_group in flat.groupby("question_id", sort=False):
        q_text = q_group["question_text"].iloc[0]
        # Question row
        qcell = ws.cell(row=current_row, column=1, value=q_text)
        qcell.font = question_font
        qcell.fill = group_fill
        # Merge across
        ws.merge_cells(
            start_row=current_row, start_column=1,
            end_row=current_row, end_column=n_banners + 1
        )
        current_row += 1

        # Collect unique response rows in stable order
        response_order = q_group[["row_type", "response_option"]].drop_duplicates().values.tolist()

        for row_type, response_opt in response_order:
            rcell = ws.cell(row=current_row, column=1, value=response_opt)
            rcell.alignment = indent_align
            if row_type in ("net", "subtotal"):
                rcell.font = Font(bold=True)
                rcell.fill = PatternFill("solid", fgColor="FFF4CC")
            elif row_type in ("mean", "median"):
                rcell.font = Font(italic=True)
                rcell.fill = PatternFill("solid", fgColor="E7E6E6")

            # Fill in banner columns
            for i, (_, banner_row) in enumerate(banner_order.iterrows(), start=2):
                bg, bv = banner_row["banner_group"], banner_row["banner_value"]
                match = q_group[
                    (q_group["row_type"] == row_type)
                    & (q_group["response_option"] == response_opt)
                    & (q_group["banner_group"] == bg)
                    & (q_group["banner_value"] == bv)
                ]
                if not match.empty:
                    val = match["value"].iloc[0]
                    sig = match["sig_markers"].iloc[0] if "sig_markers" in match.columns else None
                    if pd.notna(val):
                        value_type = match["value_type"].iloc[0]
                        if value_type == "percent":
                            display = f"{val:.0f}%"
                        elif value_type in ("mean", "median"):
                            display = f"{val:.2f}"
                        else:
                            display = f"{val:.1f}"
                        if sig and isinstance(sig, str) and sig.strip():
                            display = f"{display} {sig}"
                        cell = ws.cell(row=current_row, column=i, value=display)
                        cell.alignment = Alignment(horizontal="center")
            current_row += 1

    # Column widths
    ws.column_dimensions["A"].width = 45
    for i in range(2, n_banners + 2):
        ws.column_dimensions[get_column_letter(i)].width = 14

    # Freeze panes (below banner + base row, after col A)
    ws.freeze_panes = "B4"

    wb.save(output_path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--flat", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    flat = pd.read_csv(args.flat)
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    build_formatted_crosstab(flat, output_path)
    print(f"Formatted crosstab written to: {output_path}")


if __name__ == "__main__":
    main()
