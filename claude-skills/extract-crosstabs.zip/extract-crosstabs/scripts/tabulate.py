#!/usr/bin/env python3
"""
tabulate.py

Deterministic tabulation engine. Reads raw respondent data + a config JSON and
produces a flat-format file in the Path A schema (long and wide), plus a
methodology note.

Usage:
    python tabulate.py --input <data> --config <config.json> --output-dir <dir>
                       [--codebook <cb.csv>]
"""

import argparse
import json
import math
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


# ---------------- Data loading ----------------

def load_data(filepath: str) -> pd.DataFrame:
    path = Path(filepath)
    ext = path.suffix.lower()
    if ext == ".sav":
        import pyreadstat
        df, _ = pyreadstat.read_sav(filepath)
        return df
    elif ext == ".csv":
        return pd.read_csv(filepath)
    elif ext in (".xlsx", ".xls"):
        return pd.read_excel(filepath)
    else:
        raise ValueError(f"Unsupported file type: {ext}")


# ---------------- Base / filter helpers ----------------

def apply_filter(df: pd.DataFrame, filter_expr: str) -> pd.DataFrame:
    """Apply a Python expression as a row filter."""
    if not filter_expr:
        return df
    try:
        mask = df.eval(filter_expr)
        return df[mask]
    except Exception as e:
        raise ValueError(f"Filter expression failed: {filter_expr} — {e}")


def get_weight_series(df: pd.DataFrame, weight_var: str | None) -> pd.Series:
    """Return a Series of weights (ones if no weight var)."""
    if weight_var and weight_var in df.columns:
        w = df[weight_var].fillna(0)
        if (w < 0).any():
            raise ValueError(f"Weight variable '{weight_var}' contains negative values.")
        return w
    return pd.Series(np.ones(len(df)), index=df.index)


# ---------------- Banner iteration ----------------

def iter_banner_cuts(df: pd.DataFrame, banners: list[dict]):
    """Yield (banner_group, banner_value, banner_label, filter_series) tuples."""
    for banner in banners:
        group = banner["group_name"]
        var = banner.get("variable")
        for value in banner["values"]:
            label = value["label"]
            code = value["code"]
            if var is None:  # Total
                mask = pd.Series(True, index=df.index)
            else:
                mask = df[var] == code
            yield group, label, mask


# ---------------- Percent computation ----------------

def weighted_count(mask: pd.Series, weights: pd.Series) -> float:
    return float((mask * weights).sum())


def unweighted_count(mask: pd.Series) -> int:
    return int(mask.sum())


# ---------------- Question type handlers ----------------

def tabulate_single_response(
    df: pd.DataFrame,
    weights: pd.Series,
    q: dict,
    banners: list[dict],
) -> list[dict]:
    rows = []
    variable = q["variable"]
    value_codes = q["value_codes"]
    missing_handling = q.get("missing_handling", "exclude")
    derived = q.get("derived_measures", [])

    for bgroup, bvalue, bmask in iter_banner_cuts(df, banners):
        # Apply missing handling
        qmask = df[variable].notna() if missing_handling == "exclude" else pd.Series(True, index=df.index)
        base_mask = bmask & qmask
        base_n = weighted_count(base_mask, weights)
        base_n_unw = unweighted_count(base_mask)

        if base_n == 0:
            continue

        # Response rows
        for vc in value_codes:
            code = vc["code"]
            vmask = base_mask & (df[variable] == code)
            count = weighted_count(vmask, weights)
            pct = (count / base_n * 100) if base_n else None
            rows.append(
                _mk_row(
                    q, "response", vc["label"], bgroup, bvalue,
                    pct, "percent", int(round(base_n)), base_n_unw
                )
            )

        # Missing as its own category if requested
        if missing_handling == "include":
            miss_mask = bmask & df[variable].isna()
            miss_count = weighted_count(miss_mask, weights)
            total_base = bmask.sum() if bmask.any() else 0
            if total_base:
                miss_pct = miss_count / total_base * 100
                rows.append(
                    _mk_row(
                        q, "response", "No answer / missing", bgroup, bvalue,
                        miss_pct, "percent", int(round(total_base)), int(total_base)
                    )
                )

        # Derived (NETs)
        for d in derived:
            if d["type"] == "net":
                net_mask = base_mask & df[variable].isin(d["codes"])
                net_count = weighted_count(net_mask, weights)
                net_pct = (net_count / base_n * 100) if base_n else None
                rows.append(
                    _mk_row(
                        q, "net", d["label"], bgroup, bvalue,
                        net_pct, "percent", int(round(base_n)), base_n_unw
                    )
                )
    return rows


def tabulate_multi_response(
    df: pd.DataFrame, weights: pd.Series, q: dict, banners: list[dict]
) -> list[dict]:
    rows = []
    variables = q["variables"]  # list of column names
    option_labels = q.get("option_labels", variables)
    missing_handling = q.get("missing_handling", "exclude")
    derived = q.get("derived_measures", [])

    for bgroup, bvalue, bmask in iter_banner_cuts(df, banners):
        # Base: respondents with at least one non-null response across all options
        any_answered = df[variables].notna().any(axis=1)
        if missing_handling == "exclude":
            base_mask = bmask & any_answered
        else:
            base_mask = bmask
        base_n = weighted_count(base_mask, weights)
        base_n_unw = unweighted_count(base_mask)

        if base_n == 0:
            continue

        for var, label in zip(variables, option_labels):
            # "Selected" = value == 1 (standard binary convention)
            sel_mask = base_mask & (df[var] == 1)
            sel_count = weighted_count(sel_mask, weights)
            pct = (sel_count / base_n * 100) if base_n else None
            rows.append(
                _mk_row(
                    q, "response", label, bgroup, bvalue,
                    pct, "percent", int(round(base_n)), base_n_unw
                )
            )

        # Derived: NETs (union of specific options)
        for d in derived:
            if d["type"] == "net":
                # codes is a list of variable names in this case
                net_vars = d.get("variables", d.get("codes", []))
                net_mask = base_mask & (df[net_vars] == 1).any(axis=1)
                net_count = weighted_count(net_mask, weights)
                net_pct = (net_count / base_n * 100) if base_n else None
                rows.append(
                    _mk_row(
                        q, "net", d["label"], bgroup, bvalue,
                        net_pct, "percent", int(round(base_n)), base_n_unw
                    )
                )
    return rows


def tabulate_scale(
    df: pd.DataFrame, weights: pd.Series, q: dict, banners: list[dict]
) -> list[dict]:
    rows = []
    variable = q["variable"]
    scale_min = q["scale_min"]
    scale_max = q["scale_max"]
    missing_handling = q.get("missing_handling", "exclude")
    derived = q.get("derived_measures", [])

    for bgroup, bvalue, bmask in iter_banner_cuts(df, banners):
        qmask = df[variable].notna() if missing_handling == "exclude" else pd.Series(True, index=df.index)
        base_mask = bmask & qmask
        base_n = weighted_count(base_mask, weights)
        base_n_unw = unweighted_count(base_mask)

        if base_n == 0:
            continue

        # Per-scale-point distribution
        for point in range(scale_min, scale_max + 1):
            pmask = base_mask & (df[variable] == point)
            pct = weighted_count(pmask, weights) / base_n * 100
            rows.append(
                _mk_row(
                    q, "response", str(point), bgroup, bvalue,
                    pct, "percent", int(round(base_n)), base_n_unw
                )
            )

        # Derived
        vals = df.loc[base_mask, variable]
        w = weights.loc[base_mask]
        for d in derived:
            if d["type"] == "mean":
                mean_val = _weighted_mean(vals, w)
                rows.append(
                    _mk_row(q, "mean", d["label"], bgroup, bvalue, mean_val, "mean", int(round(base_n)), base_n_unw)
                )
            elif d["type"] == "median":
                med_val = _weighted_median(vals, w)
                rows.append(
                    _mk_row(q, "median", d["label"], bgroup, bvalue, med_val, "median", int(round(base_n)), base_n_unw)
                )
            elif d["type"] == "net":
                net_mask = base_mask & df[variable].isin(d["codes"])
                net_pct = weighted_count(net_mask, weights) / base_n * 100
                rows.append(
                    _mk_row(q, "net", d["label"], bgroup, bvalue, net_pct, "percent", int(round(base_n)), base_n_unw)
                )
            elif d["type"] == "top_box":
                mask = base_mask & (df[variable] == scale_max)
                pct = weighted_count(mask, weights) / base_n * 100
                rows.append(
                    _mk_row(q, "net", d["label"], bgroup, bvalue, pct, "percent", int(round(base_n)), base_n_unw)
                )
            elif d["type"] == "bottom_box":
                mask = base_mask & (df[variable] == scale_min)
                pct = weighted_count(mask, weights) / base_n * 100
                rows.append(
                    _mk_row(q, "net", d["label"], bgroup, bvalue, pct, "percent", int(round(base_n)), base_n_unw)
                )
    return rows


def tabulate_ranked(
    df: pd.DataFrame, weights: pd.Series, q: dict, banners: list[dict]
) -> list[dict]:
    rows = []
    variables = q["variables"]  # one per rank position
    rank_positions = q["rank_positions"]
    value_codes = q["value_codes"]
    derived = q.get("derived_measures", [])

    for bgroup, bvalue, bmask in iter_banner_cuts(df, banners):
        # Base: respondents who provided rank 1 (usually required)
        base_mask = bmask & df[variables[0]].notna()
        base_n = weighted_count(base_mask, weights)
        base_n_unw = unweighted_count(base_mask)
        if base_n == 0:
            continue

        # For each option × each rank position
        for vc in value_codes:
            code = vc["code"]
            option_label = vc["label"]
            for var, pos in zip(variables, rank_positions):
                rmask = base_mask & (df[var] == code)
                pct = weighted_count(rmask, weights) / base_n * 100
                rows.append(
                    _mk_row(
                        q, "response", f"{option_label} — Rank {pos}",
                        bgroup, bvalue, pct, "percent", int(round(base_n)), base_n_unw,
                    )
                )

            # Derived per-option
            for d in derived:
                if d["type"] == "any_mention":
                    amask = base_mask & (df[variables] == code).any(axis=1)
                    am_pct = weighted_count(amask, weights) / base_n * 100
                    rows.append(
                        _mk_row(
                            q, "net", f"{option_label} — Any mention",
                            bgroup, bvalue, am_pct, "percent", int(round(base_n)), base_n_unw,
                        )
                    )
                elif d["type"] == "mean_rank":
                    # Mean rank position for this option across respondents
                    ranks_for_option = []
                    w_for_option = []
                    for var, pos in zip(variables, rank_positions):
                        mask = base_mask & (df[var] == code)
                        for idx in df[mask].index:
                            ranks_for_option.append(pos)
                            w_for_option.append(weights.loc[idx])
                    if ranks_for_option:
                        mean_rank = np.average(ranks_for_option, weights=w_for_option)
                        rows.append(
                            _mk_row(
                                q, "mean", f"{option_label} — Mean rank",
                                bgroup, bvalue, mean_rank, "mean", int(round(base_n)), base_n_unw,
                            )
                        )
    return rows


def tabulate_numeric_open(
    df: pd.DataFrame, weights: pd.Series, q: dict, banners: list[dict]
) -> list[dict]:
    rows = []
    variable = q["variable"]
    missing_handling = q.get("missing_handling", "exclude")
    derived = q.get("derived_measures", [])
    filter_expr = q.get("filter")

    for bgroup, bvalue, bmask in iter_banner_cuts(df, banners):
        qmask = df[variable].notna() if missing_handling == "exclude" else pd.Series(True, index=df.index)
        base_mask = bmask & qmask

        # Optional outlier filter
        if filter_expr:
            temp_df = df.rename(columns={variable: "value"})
            keep = temp_df.eval(filter_expr)
            base_mask = base_mask & keep

        base_n = weighted_count(base_mask, weights)
        base_n_unw = unweighted_count(base_mask)
        if base_n == 0:
            continue

        vals = df.loc[base_mask, variable]
        w = weights.loc[base_mask]

        for d in derived:
            if d["type"] == "mean":
                rows.append(
                    _mk_row(q, "mean", d["label"], bgroup, bvalue,
                            _weighted_mean(vals, w), "mean", int(round(base_n)), base_n_unw)
                )
            elif d["type"] == "median":
                rows.append(
                    _mk_row(q, "median", d["label"], bgroup, bvalue,
                            _weighted_median(vals, w), "median", int(round(base_n)), base_n_unw)
                )
            elif d["type"] == "band":
                band_mask = base_mask & (df[variable] >= d["min"]) & (df[variable] <= d["max"])
                band_pct = weighted_count(band_mask, weights) / base_n * 100
                rows.append(
                    _mk_row(q, "response", d["label"], bgroup, bvalue,
                            band_pct, "percent", int(round(base_n)), base_n_unw)
                )
    return rows


# ---------------- Helpers ----------------

def _mk_row(q, row_type, response_option, bgroup, bvalue, value, value_type, base_n, base_n_unw):
    return {
        "source_sheet": q.get("question_id", ""),
        "question_id": q["question_id"],
        "question_text": q["question_text"],
        "row_type": row_type,
        "response_option": response_option,
        "banner_group": bgroup,
        "banner_value": bvalue,
        "value": round(value, 2) if value is not None and not pd.isna(value) else None,
        "value_type": value_type,
        "base_n": base_n,
        "base_n_unweighted": base_n_unw,
        "sig_markers": None,
    }


def _weighted_mean(values: pd.Series, weights: pd.Series):
    values = values.dropna()
    weights = weights.loc[values.index]
    if weights.sum() == 0:
        return None
    return float(np.average(values, weights=weights))


def _weighted_median(values: pd.Series, weights: pd.Series):
    values = values.dropna()
    weights = weights.loc[values.index]
    if weights.sum() == 0:
        return None
    sorted_idx = values.sort_values().index
    vals_sorted = values.loc[sorted_idx]
    w_sorted = weights.loc[sorted_idx]
    cumw = w_sorted.cumsum()
    total = w_sorted.sum()
    median_idx = cumw[cumw >= total / 2].index[0]
    return float(vals_sorted.loc[median_idx])


# ---------------- Dispatch ----------------

HANDLERS = {
    "single_response": tabulate_single_response,
    "multi_response": tabulate_multi_response,
    "scale": tabulate_scale,
    "ranked": tabulate_ranked,
    "numeric_open": tabulate_numeric_open,
}


# ---------------- Significance testing ----------------

def apply_significance_testing(flat: pd.DataFrame, sig_config: dict) -> pd.DataFrame:
    """
    Compute column-to-column significance and populate sig_markers.

    For z-proportion tests: compares each banner value's proportion to
    every other banner value in the same banner_group, per question × response.
    """
    if not sig_config or not sig_config.get("enabled"):
        return flat

    from scipy.stats import norm

    confidence = sig_config.get("confidence_level", 0.95)
    z_crit = norm.ppf(1 - (1 - confidence) / 2)
    test_type = sig_config.get("test_type", "z_proportion")

    # Assign a letter to each banner_value for labelling
    letters = {}
    for bgroup in flat["banner_group"].unique():
        vals = [v for v in flat[flat["banner_group"] == bgroup]["banner_value"].unique()]
        for i, v in enumerate(vals):
            letters[(bgroup, v)] = chr(ord("A") + i)

    # Only run on percent or mean rows
    relevant = flat[flat["value_type"].isin(["percent", "mean"])].copy()
    relevant["sig_markers"] = None

    # Group by question, response, banner_group, value_type
    grouped = relevant.groupby(["question_id", "response_option", "banner_group", "value_type"])
    marker_map = {}
    for (qid, resp, bgroup, vtype), group in grouped:
        if len(group) < 2:
            continue
        for i, row_i in group.iterrows():
            markers = []
            for j, row_j in group.iterrows():
                if i == j:
                    continue
                if row_i["value"] is None or row_j["value"] is None:
                    continue
                if pd.isna(row_i["value"]) or pd.isna(row_j["value"]):
                    continue
                # z-test for proportions (simplified; uses base_n)
                if vtype == "percent" and test_type in ("z_proportion", "both"):
                    p1 = row_i["value"] / 100
                    p2 = row_j["value"] / 100
                    n1 = row_i["base_n"]
                    n2 = row_j["base_n"]
                    if n1 and n2 and n1 > 0 and n2 > 0:
                        p_pool = (p1 * n1 + p2 * n2) / (n1 + n2)
                        se = math.sqrt(p_pool * (1 - p_pool) * (1 / n1 + 1 / n2))
                        if se > 0:
                            z = (p1 - p2) / se
                            if z > z_crit:
                                markers.append(letters.get((bgroup, row_j["banner_value"]), ""))
            if markers:
                marker_map[i] = "".join(sorted(set(markers)))

    # Apply markers back to the full flat dataframe
    for idx, mk in marker_map.items():
        flat.at[idx, "sig_markers"] = mk

    return flat


# ---------------- Output ----------------

def write_methodology_note(config: dict, out_path: Path, row_count: int, base_n: int):
    lines = [
        f"# Methodology — {config.get('study_id', 'study')}",
        "",
        f"Run at: {datetime.now().isoformat(timespec='seconds')}",
        f"Wave: {config.get('wave', '(not specified)')}",
        "",
        "## Sample",
        "",
        f"- Total rows in raw file: {row_count}",
        f"- Base (qualified respondents): {base_n}",
        f"- Base filter: `{config.get('base_filter', 'none')}`",
        "",
        "## Weighting",
        "",
    ]
    if config.get("weight_variable"):
        lines += [
            f"- Weighted tabulations: **yes**",
            f"- Weight variable: `{config['weight_variable']}`",
            f"- Weighting scheme: {config.get('weighting_description', '(not described)')}",
        ]
    else:
        lines += ["- Weighted tabulations: **no** (unweighted)"]
    lines += ["", "## Banners", ""]
    for b in config["banners"]:
        lines.append(f"- **{b['group_name']}** (variable: `{b.get('variable', 'N/A')}`)")
        for v in b["values"]:
            lines.append(f"  - {v['label']} (code: {v['code']})")
    lines += ["", "## Questions tabulated", ""]
    for q in config["questions"]:
        lines.append(f"- **{q['question_id']}** — {q['question_text']} ({q['question_type']})")
        if q.get("conditional_base"):
            lines.append(f"  - Conditional base: `{q['conditional_base']}`")
        if q.get("missing_handling"):
            lines.append(f"  - Missing handling: {q['missing_handling']}")
        for d in q.get("derived_measures", []):
            lines.append(f"  - Derived: {d.get('label', d['type'])}")
    if config.get("significance", {}).get("enabled"):
        sc = config["significance"]
        lines += [
            "",
            "## Significance testing",
            "",
            f"- Test type: {sc.get('test_type', 'z_proportion')}",
            f"- Confidence level: {int(sc.get('confidence_level', 0.95) * 100)}%",
            f"- Multiple-comparison correction: {sc.get('correction', 'none')}",
        ]
    else:
        lines += ["", "## Significance testing", "", "- Not applied"]
    out_path.write_text("\n".join(lines), encoding="utf-8")


def pivot_to_wide(long_df: pd.DataFrame) -> pd.DataFrame:
    if long_df.empty:
        return long_df
    long_df = long_df.copy()
    long_df["banner_col"] = long_df["banner_group"] + "_" + long_df["banner_value"].astype(str)
    index_cols = [
        "source_sheet",
        "question_id",
        "question_text",
        "row_type",
        "response_option",
        "value_type",
    ]
    wide = long_df.pivot_table(
        index=index_cols,
        columns="banner_col",
        values="value",
        aggfunc="first",
    ).reset_index()
    return wide


# ---------------- Main ----------------

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--config", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--codebook", default=None)
    args = parser.parse_args()

    with open(args.config) as f:
        config = json.load(f)

    df = load_data(args.input)
    original_rows = len(df)

    # Base filter
    if config.get("base_filter"):
        df = apply_filter(df, config["base_filter"])
    base_n = len(df)

    weights = get_weight_series(df, config.get("weight_variable"))

    all_rows = []
    for q in config["questions"]:
        # Conditional base
        if q.get("conditional_base"):
            sub_df = apply_filter(df, q["conditional_base"])
            sub_weights = weights.loc[sub_df.index]
        else:
            sub_df = df
            sub_weights = weights

        handler = HANDLERS.get(q["question_type"])
        if not handler:
            print(f"WARNING: Unknown question type {q['question_type']} for {q['question_id']} — skipping", file=sys.stderr)
            continue
        all_rows.extend(handler(sub_df, sub_weights, q, config["banners"]))

    flat = pd.DataFrame(all_rows)

    # Significance testing
    if config.get("significance", {}).get("enabled"):
        flat = apply_significance_testing(flat, config["significance"])

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = config.get("study_id", "study")
    wave = config.get("wave", "")
    if wave:
        stem = f"{stem}_{wave}"

    # Long
    long_csv = out_dir / f"flat_{stem}_long.csv"
    long_xlsx = out_dir / f"flat_{stem}_long.xlsx"
    flat.to_csv(long_csv, index=False, encoding="utf-8-sig")
    flat.to_excel(long_xlsx, index=False)

    # Wide
    wide = pivot_to_wide(flat)
    wide_csv = out_dir / f"flat_{stem}_wide.csv"
    wide_xlsx = out_dir / f"flat_{stem}_wide.xlsx"
    wide.to_csv(wide_csv, index=False, encoding="utf-8-sig")
    wide.to_excel(wide_xlsx, index=False)

    # Methodology
    method_path = out_dir / f"methodology_{stem}.md"
    write_methodology_note(config, method_path, original_rows, base_n)

    result = {
        "rows_written": len(flat),
        "unique_questions": flat["question_id"].nunique() if not flat.empty else 0,
        "base_n": base_n,
        "outputs": {
            "long_csv": str(long_csv),
            "long_xlsx": str(long_xlsx),
            "wide_csv": str(wide_csv),
            "wide_xlsx": str(wide_xlsx),
            "methodology": str(method_path),
        },
    }
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
