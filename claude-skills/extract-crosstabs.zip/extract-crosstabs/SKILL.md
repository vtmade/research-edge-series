---
name: extract-crosstabs
description: Generate flat-format crosstabs from raw respondent-level survey data (.sav, .csv, or .xlsx) for downstream LLM and Python analysis. Handles single-response, multi-response, scale, ranked, and numeric question types with full codebook support, optional weighting, conditional bases, custom NETs, and optional significance testing. Use this skill whenever the user has raw survey data and needs to produce crosstabs — not when they already have a crosstab deliverable (use flatten-crosstab instead). Trigger on /extract-crosstabs or when the user says "tabulate this raw data", "generate crosstabs from this SPSS/SAV file", "cross-cut this respondent-level dataset", "run tabs on this survey", or similar.
---

# extract-crosstabs

Generate crosstabs from raw respondent-level survey data. The output is both a flat-format file (for LLM/pipeline use) and a formatted crosstab Excel (for human reading and as valid input to the flatten-crosstab skill).

This skill replaces the traditional DP-platform tabulation workflow for studies where the analyst has raw data and wants to produce their own crosstabs — or the crosstabs needed for a specific advanced analysis.

## When to use this skill

Use when the user has:

- Raw respondent-level data (one row per respondent, one column per variable) in `.sav`, `.csv`, or `.xlsx`
- A codebook describing the variables (or a `.sav` file with embedded metadata)
- A need to produce crosstabs themselves rather than wait for a DP deliverable

Do not use when:

- The user has a crosstab deliverable already — use **flatten-crosstab** instead
- The data is at respondent level but the analysis is multivariate (driver analysis, regression, segmentation, clustering, factor analysis) — that's Path B territory, not crosstabs

Typical triggers:

- `/extract-crosstabs` slash command
- "tabulate this raw data"
- "generate crosstabs from this SPSS file"
- "cross-cut this dataset by demographics"
- "run tabs on this survey"

## Core principle

The LLM interprets. Python computes.

The LLM reads the codebook, helps the analyst configure the tabulation (which variables are banners, which are questions, which derived measures to generate), and interprets the output. Python executes the tabulation deterministically using pandas. Every value in every output traces back to a respondent row + a rule.

## Workflow

Follow `reference/workflow.md` step-by-step. Each step de-risks the next.

**Summary of stages:**

1. **Receive the raw data file** from the analyst.
2. **Load and inspect** — extract metadata (for .sav) or request a codebook (for .csv/.xlsx).
3. **Confirm the codebook with the analyst** — variable labels, value codes, question types. This is the belt-and-braces step; do not skip.
4. **Configure the tabulation** interactively:
   - Banner variables (which columns define the cuts)
   - Question variables (which columns to tabulate)
   - Base definition (qualified respondents; apply any conditional filters)
   - Weighting (optional; which variable, what scheme)
   - Missing-data handling (per question: include, exclude, null)
   - Derived measures (NETs, means, top/bottom boxes — auto-generated defaults for analyst to edit)
   - Significance testing (optional; test type, confidence level, correction)
5. **Tabulate** using `scripts/tabulate.py`. Runs deterministically.
6. **Generate outputs** — flat file (CSV + Excel, long + wide, in the Path A schema) and a formatted crosstab Excel for human reading.
7. **Generate the methodology note** documenting every decision made.
8. **Summarise to the analyst** — what was produced, where, any flags.

## Output schema

The flat file uses the exact same schema as Path A's `flatten-crosstab` output. This means:

- The same columns (source_sheet, question_id, question_text, row_type, response_option, banner_group, banner_value, value, value_type, base_n, sig_markers)
- The same row_type taxonomy (response, net, subtotal, mean, median)
- Fully compatible with any downstream tool or analysis that consumes Path A output

The formatted crosstab Excel mimics a traditional DP deliverable — banner rows at the top, questions in column A, response options indented, base sizes included. This file is also valid input to `flatten-crosstab`, so Path A and Path C chain cleanly.

## Question-type handling

See `reference/question-types.md` for details. Summary of aggregation rules:

| Question type | Aggregation |
|---|---|
| **Single-response** | Frequency distribution as percent of base |
| **Multi-response** | Percent of base mentioning each option (sum may exceed 100) |
| **Scale / Likert** | Full distribution + mean + NET Top 2 / Bottom 2 (analyst-configurable) |
| **Ranked** | Distribution of rank positions + mean rank + "any mention" |
| **Numeric open** | Mean, median, min, max + optional banded frequency distribution |

## Dependencies

- Python 3.10+
- `pandas`
- `pyreadstat` (for .sav files)
- `openpyxl` (for .xlsx read/write)
- `scipy` (for significance testing)
- `numpy`

Install if missing:

```bash
pip install pandas pyreadstat openpyxl scipy numpy --break-system-packages
```

## Non-negotiable rules

- **Codebook confirmation is required.** Never tabulate without the analyst confirming the codebook. Silent codebook errors propagate into every row of every table.
- **Qualified respondents only.** Non-qualified respondents (screened out) are excluded from the analytical base by default. Screener variables remain available as banner dimensions.
- **Weighting is analyst-driven.** Never apply weights without explicit instruction. The methodology note always records whether the output is weighted or not.
- **No imputation.** Missing data is handled by exclusion, inclusion as a category, or nulling — never by imputation. Analytical decisions about missing data belong to the researcher.
- **Python tabulates; the LLM never does.** All counts, percentages, means, and significance tests are computed by pandas/scipy. The LLM's role is configuration and interpretation.
- **Every run is fresh.** No cached configurations between runs. If the analyst wants to reuse a config, they save the config JSON and pass it explicitly.
- **Methodology note is mandatory.** Every tabulation produces a methodology note. No exceptions.

## Files in this skill

```
extract-crosstabs/
├── SKILL.md                          # This file
├── reference/
│   ├── workflow.md                   # Step-by-step interaction
│   ├── question-types.md             # Aggregation rules per type
│   ├── codebook-schema.md            # Codebook format for CSV/Excel inputs
│   ├── config-schema.md              # Tabulation config schema
│   └── codebook.example.csv          # Sample codebook
└── scripts/
    ├── load_and_inspect.py           # Reads file, extracts metadata, proposes codebook
    ├── tabulate.py                   # Deterministic tabulation engine
    └── format_crosstab.py            # Produces the human-readable Excel
```
