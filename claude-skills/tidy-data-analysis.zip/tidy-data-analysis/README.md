# tidy-data-analysis

A Claude Code skill for analysing flat-format survey data (produced by `flatten-crosstab` or `extract-crosstabs`) — the stage between clean data and the written report. The skill helps an analyst work through research objectives, pin findings with evidence, and export a structured finding set for report-writing.

This is a thinking partner, not a report-writer. It never generates prose findings. Every pinned finding is the analyst's call, with the skill proposing the moves, computing the numbers, and surfacing things worth a second look.

---

## Install

Drop the folder into your Claude Code skills directory:

```bash
cp -r tidy-data-analysis ~/.claude/skills/
```

---

## Invoke

```
/analyse-flat
```

Or say it naturally:

> "analyse this flat file"
> "help me find insights in this crosstab"
> "work through my research objectives on this data"

---

## What it does

Takes a flat file + research objectives + hypotheses (optional) and produces:

- **findings_<studyname>.md** — pinned findings organised by objective, each with observation, context, note, and sanity-check flags
- **tables/finding_<id>.csv** — the rows of the flat file each finding draws on (audit trail)
- **open_questions_<studyname>.md** — objectives or threads the analyst flagged but didn't resolve
- **session.json** — full session state, resumable across sittings

---

## Workflow

1. You share the flat file.
2. Skill checks for an existing session — resume or start fresh.
3. You supply research objectives.
4. Skill proposes which questions and banner cuts map to each objective; you confirm.
5. You pick an objective to work on (jump between them freely).
6. Skill proposes analytical moves; you approve which to run.
7. Skill executes via pandas; returns tables (never prose).
8. You pin findings with observation + context + your note.
9. Four sanity checks run automatically: base size, contradiction, against-hypothesis, small-difference.
10. Export when ready.

---

## The four sanity checks

Every pinned finding is auto-checked:

- **Base size** — flagged if base < 50 (low), < 30 (high)
- **Contradiction** — flagged if it conflicts with another pinned finding
- **Against-hypothesis** — flagged (as info) if it goes against a hypothesis you set
- **Small difference** — flagged if the gap is under 5pp (low) or under 3pp (medium)

Flags never block pinning. They surface caveats so the analyst sees them.

---

## What the skill deliberately doesn't do

- **Write findings in prose.** The observation is auto-filled from a Python query. The context is a proposal you edit. The note is yours entirely.
- **Generate slide copy or deck bullets.** The output is analytical scaffolding, not presentation content.
- **Run analysis you didn't approve.** Every move is proposed → approved → run → reviewed.
- **Cache findings between studies.** Every session starts fresh unless you explicitly resume.

---

## Non-negotiables

- Every observation traces back to specific rows of the flat file.
- Every finding is tied to an objective (or flagged as "interesting but unmapped" in open questions).
- Sanity checks run on every pin automatically.
- Session state persists; you can stop and resume across multiple sittings.
- Python computes; the LLM interprets and proposes. No direct LLM-to-number transcription.

---

## Files in this folder

```
tidy-data-analysis/
├── SKILL.md                          # Skill trigger + workflow (read by Claude Code)
├── README.md                         # This file
├── reference/
│   ├── workflow.md                   # Step-by-step interaction
│   ├── analytical-moves.md           # Catalogue of cuts the skill can propose
│   ├── sanity-checks.md              # Four auto-checks, defined precisely
│   └── session-schema.md             # session.json structure
└── scripts/
    ├── session_manager.py            # Init, load, save, summarise sessions
    ├── analytical_engine.py          # Executes analytical moves deterministically
    ├── sanity_check.py               # Runs four checks per finding
    └── export.py                     # Writes findings.md + tables/ + open_questions.md
```

---

## How this fits with the rest of the framework

Three skills in sequence:

| Skill | Purpose |
|---|---|
| `flatten-crosstab` or `extract-crosstabs` | Get data into flat format |
| **`tidy-data-analysis`** | Find and pin findings that answer the research objectives |
| _Report-writing_ | Use the findings.md as scaffolding; turn pinned findings into prose |

Each stage leaves a clean, auditable artefact for the next.

---

## Feedback

This is a working draft. The most interesting feedback is about the analytical moves catalogue — which moves you reach for that aren't there, which proposed moves feel off, which sanity checks miss things they should catch. Concrete examples from real work help most.
