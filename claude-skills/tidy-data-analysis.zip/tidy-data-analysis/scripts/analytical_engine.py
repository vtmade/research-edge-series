#!/usr/bin/env python3
"""
analytical_engine.py

Deterministic execution of analytical moves against a flat file. Every move
returns a table — never prose. The LLM consumes these tables and proposes
contexts for the analyst to accept or edit.

Usage:
    python analytical_engine.py --flat <flat.csv> --move <move.json>

The move.json contains:
    {
        "type": "compare_banner_values",
        "parameters": { ... }
    }

Output: JSON with "rows" (the result table), "base_summary", and "source_rows"
(pointers back to the flat file rows used).
"""

import argparse
import json
import sys
from pathlib import Path

import pandas as pd
import numpy as np


# ---------- Helpers ----------

def _filter(df: pd.DataFrame, **kwargs) -> pd.DataFrame:
    """Filter a DataFrame by exact matches on multiple columns."""
    out = df
    for col, val in kwargs.items():
        if val is None:
            continue
        if isinstance(val, (list, tuple)):
            out = out[out[col].isin(val)]
        else:
            out = out[out[col] == val]
    return out


def _source_rows(df: pd.DataFrame) -> list[dict]:
    """Return the source row pointers: question/row/banner only, not value."""
    cols = ["question_id", "row_type", "response_option", "banner_group", "banner_value"]
    return df[cols].drop_duplicates().to_dict(orient="records")


# ---------- Moves ----------

def compare_banner_values(df, params):
    qid = params["question_id"]
    response = params.get("response_option")
    row_type = params.get("row_type", "response" if not response or "NET" not in str(response).upper() else "net")
    banner_group = params["banner_group"]

    sub = _filter(df, question_id=qid, row_type=row_type, banner_group=banner_group)
    if response:
        sub = sub[sub["response_option"] == response]

    if sub.empty:
        return {"rows": [], "base_summary": {}, "source_rows": [], "warning": "No matching rows"}

    rows = sub[["banner_value", "value", "base_n", "value_type", "sig_markers"]].to_dict(
        orient="records"
    )
    return {
        "rows": rows,
        "question_text": sub["question_text"].iloc[0],
        "response_option": response or sub["response_option"].iloc[0],
        "row_type": row_type,
        "banner_group": banner_group,
        "base_summary": {
            "min_base": int(sub["base_n"].min()) if sub["base_n"].notna().any() else None,
            "max_base": int(sub["base_n"].max()) if sub["base_n"].notna().any() else None,
        },
        "source_rows": _source_rows(sub),
    }


def drilldown_within_cut(df, params):
    qid = params["question_id"]
    banner_group = params["banner_group"]
    banner_value = params["banner_value"]

    sub = _filter(
        df, question_id=qid, banner_group=banner_group, banner_value=banner_value
    ).sort_values("response_option")

    if sub.empty:
        return {"rows": [], "warning": "No matching rows"}

    rows = sub[["row_type", "response_option", "value", "value_type", "base_n"]].to_dict(
        orient="records"
    )
    return {
        "rows": rows,
        "question_text": sub["question_text"].iloc[0],
        "cut": f"{banner_group} × {banner_value}",
        "base_summary": {
            "base_n": int(sub["base_n"].iloc[0]) if sub["base_n"].notna().any() else None,
        },
        "source_rows": _source_rows(sub),
    }


def crosscut_within_group(df, params):
    qid = params["question_id"]
    primary = params["primary_banner_group"]
    secondary = params["secondary_banner_group"]
    response = params.get("response_option")

    # For each primary × secondary pair, find the value
    # NB: flat file has each cut on its own; cross-cutting requires the DP/extractor
    # to have produced interaction cuts. If those aren't present, we can only report
    # primary and secondary separately.
    primary_sub = _filter(df, question_id=qid, banner_group=primary)
    secondary_sub = _filter(df, question_id=qid, banner_group=secondary)

    if response:
        primary_sub = primary_sub[primary_sub["response_option"] == response]
        secondary_sub = secondary_sub[secondary_sub["response_option"] == response]

    return {
        "note": "Cross-cut tables require interaction cuts in the flat file. Showing primary and secondary separately.",
        "primary": primary_sub[["banner_value", "response_option", "row_type", "value", "base_n"]].to_dict(orient="records"),
        "secondary": secondary_sub[["banner_value", "response_option", "row_type", "value", "base_n"]].to_dict(orient="records"),
        "source_rows": _source_rows(pd.concat([primary_sub, secondary_sub])),
    }


def rank_gaps(df, params):
    banner_group = params["banner_group"]
    value_a = params["banner_value_a"]
    value_b = params["banner_value_b"]
    threshold = params.get("threshold", 5)
    response_filter = params.get("response_filter", "net_and_mean")
    # response_filter: "all" | "response_only" | "net_only" | "net_and_mean"

    sub = _filter(df, banner_group=banner_group, banner_value=[value_a, value_b])
    if response_filter == "response_only":
        sub = sub[sub["row_type"] == "response"]
    elif response_filter == "net_only":
        sub = sub[sub["row_type"] == "net"]
    elif response_filter == "net_and_mean":
        sub = sub[sub["row_type"].isin(["net", "mean"])]

    # Pivot
    pivot = sub.pivot_table(
        index=["question_id", "question_text", "row_type", "response_option", "value_type"],
        columns="banner_value",
        values="value",
        aggfunc="first",
    ).reset_index()
    if value_a not in pivot.columns or value_b not in pivot.columns:
        return {"rows": [], "warning": f"Missing {value_a} or {value_b} in data"}

    pivot["gap"] = pivot[value_a] - pivot[value_b]
    pivot["abs_gap"] = pivot["gap"].abs()
    pivot = pivot[pivot["abs_gap"] >= threshold].sort_values("abs_gap", ascending=False)

    rows = pivot[
        ["question_id", "question_text", "row_type", "response_option", value_a, value_b, "gap"]
    ].rename(columns={value_a: f"value_{value_a}", value_b: f"value_{value_b}"}).to_dict(orient="records")
    return {
        "rows": rows,
        "banner_group": banner_group,
        "comparison": f"{value_a} vs {value_b}",
        "threshold": threshold,
        "n_found": len(rows),
        "source_rows": _source_rows(sub),
    }


def find_reversals(df, params):
    banner_group = params["banner_group"]
    value_a = params["banner_value_a"]
    value_b = params["banner_value_b"]
    typical = params.get("typical_direction", "a_higher_than_b")
    # typical_direction: "a_higher_than_b" | "b_higher_than_a"

    result = rank_gaps(df, {**params, "threshold": 0, "response_filter": "net_and_mean"})
    if "rows" not in result or not result["rows"]:
        return result

    if typical == "a_higher_than_b":
        reversed_rows = [r for r in result["rows"] if r["gap"] < 0]
    else:
        reversed_rows = [r for r in result["rows"] if r["gap"] > 0]

    return {
        "rows": reversed_rows,
        "banner_group": banner_group,
        "typical_direction": typical,
        "n_reversals": len(reversed_rows),
        "source_rows": result.get("source_rows", []),
    }


def outlier_cut(df, params):
    qid = params["question_id"]
    response = params.get("response_option")
    row_type = params.get("row_type", "response")
    method = params.get("method", "std_dev")

    sub = _filter(df, question_id=qid, row_type=row_type)
    if response:
        sub = sub[sub["response_option"] == response]
    # Exclude the Total row from stats
    sub_no_total = sub[~((sub["banner_group"] == "Total") & (sub["banner_value"] == "Total"))]

    if len(sub_no_total) < 3:
        return {"rows": [], "warning": "Not enough banner cuts for outlier detection."}

    vals = sub_no_total["value"].dropna()
    if method == "std_dev":
        mean = vals.mean()
        sd = vals.std()
        if sd == 0 or pd.isna(sd):
            return {"rows": [], "warning": "No variance across cuts."}
        sub_no_total = sub_no_total.assign(z=(sub_no_total["value"] - mean) / sd)
        outliers = sub_no_total[sub_no_total["z"].abs() > 1.5]
    else:
        q1, q3 = vals.quantile(0.25), vals.quantile(0.75)
        iqr = q3 - q1
        outliers = sub_no_total[
            (sub_no_total["value"] < q1 - 1.5 * iqr) | (sub_no_total["value"] > q3 + 1.5 * iqr)
        ]

    rows = outliers[
        ["banner_group", "banner_value", "value", "base_n"]
    ].to_dict(orient="records")
    return {
        "rows": rows,
        "question_id": qid,
        "response_option": response,
        "method": method,
        "n_outliers": len(rows),
        "source_rows": _source_rows(outliers),
    }


def base_size_scan(df, params):
    threshold = params.get("threshold", 50)
    sub = df[df["base_n"] < threshold]
    if sub.empty:
        return {"rows": [], "n_flagged": 0}

    rows = (
        sub[["question_id", "banner_group", "banner_value", "base_n"]]
        .drop_duplicates()
        .sort_values("base_n")
        .to_dict(orient="records")
    )
    return {"rows": rows, "threshold": threshold, "n_flagged": len(rows)}


def cross_question_check(df, params):
    qids = params["question_ids"]
    banner_group = params.get("banner_group", "Total")
    banner_value = params.get("banner_value", "Total")
    response = params.get("response_option")

    sub = _filter(df, question_id=qids, banner_group=banner_group, banner_value=banner_value)
    if response:
        sub = sub[sub["response_option"] == response]
    sub = sub.sort_values("question_id")

    rows = sub[
        ["question_id", "question_text", "row_type", "response_option", "value", "value_type", "base_n"]
    ].to_dict(orient="records")
    return {
        "rows": rows,
        "cut": f"{banner_group} × {banner_value}",
        "response_filter": response,
        "source_rows": _source_rows(sub),
    }


def response_ranking(df, params):
    qid = params["question_id"]
    banner_group = params.get("banner_group", "Total")
    banner_value = params.get("banner_value", "Total")
    top_n = params.get("top_n")

    sub = _filter(
        df, question_id=qid, banner_group=banner_group, banner_value=banner_value, row_type="response"
    ).sort_values("value", ascending=False)

    if top_n:
        sub = sub.head(top_n)

    rows = sub[["response_option", "value", "value_type", "base_n"]].to_dict(orient="records")
    return {
        "rows": rows,
        "question_text": sub["question_text"].iloc[0] if not sub.empty else None,
        "cut": f"{banner_group} × {banner_value}",
        "source_rows": _source_rows(sub),
    }


def scale_shape(df, params):
    qid = params["question_id"]
    banner_group = params.get("banner_group", "Total")
    banner_value = params.get("banner_value", "Total")

    sub = _filter(df, question_id=qid, banner_group=banner_group, banner_value=banner_value)
    responses = sub[sub["row_type"] == "response"].sort_values("response_option")
    means = sub[sub["row_type"] == "mean"]
    medians = sub[sub["row_type"] == "median"]

    distribution = responses[["response_option", "value"]].to_dict(orient="records")

    shape = {
        "distribution": distribution,
        "mean": float(means["value"].iloc[0]) if not means.empty else None,
        "median": float(medians["value"].iloc[0]) if not medians.empty else None,
        "top_value": float(responses["value"].max()) if not responses.empty else None,
        "bottom_value": float(responses["value"].min()) if not responses.empty else None,
        "cut": f"{banner_group} × {banner_value}",
        "source_rows": _source_rows(sub),
    }
    return shape


# ---------- Dispatch ----------

DISPATCHER = {
    "compare_banner_values": compare_banner_values,
    "drilldown_within_cut": drilldown_within_cut,
    "crosscut_within_group": crosscut_within_group,
    "rank_gaps": rank_gaps,
    "find_reversals": find_reversals,
    "outlier_cut": outlier_cut,
    "base_size_scan": base_size_scan,
    "cross_question_check": cross_question_check,
    "response_ranking": response_ranking,
    "scale_shape": scale_shape,
}


def run_move(flat_path: str, move: dict) -> dict:
    df = pd.read_csv(flat_path)
    handler = DISPATCHER.get(move["type"])
    if not handler:
        return {"error": f"Unknown move type: {move['type']}"}
    return handler(df, move.get("parameters", {}))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--flat", required=True)
    parser.add_argument("--move", required=True, help="Path to move JSON")
    args = parser.parse_args()

    with open(args.move) as f:
        move = json.load(f)

    result = run_move(args.flat, move)
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
