#!/usr/bin/env python3
"""
sanity_check.py

Runs the four sanity checks against a proposed or pinned finding:
1. Base size
2. Within-study contradiction
3. Against-hypothesis
4. Small difference

Usage:
    python sanity_check.py --session <session.json> --finding <finding.json> --flat <flat.csv>
"""

import argparse
import json
import re
from pathlib import Path

import pandas as pd


def check_base_size(finding: dict, flat: pd.DataFrame) -> dict:
    """Check 1 — Base size."""
    source_rows = finding.get("source_rows", [])
    if not source_rows:
        return {"check": "base_size", "severity": "unknown", "message": "No source rows to evaluate."}

    # Find the minimum base_n across source rows
    min_base = None
    for sr in source_rows:
        mask = pd.Series(True, index=flat.index)
        for col, val in sr.items():
            mask = mask & (flat[col] == val)
        matching = flat[mask]
        if not matching.empty:
            base_values = matching["base_n"].dropna()
            if not base_values.empty:
                candidate = int(base_values.min())
                if min_base is None or candidate < min_base:
                    min_base = candidate

    if min_base is None:
        return {
            "check": "base_size",
            "severity": "unknown",
            "message": "Could not determine base size from source rows.",
        }

    if min_base >= 50:
        return {
            "check": "base_size",
            "severity": "none",
            "message": f"Base n={min_base}. OK.",
        }
    if min_base >= 30:
        return {
            "check": "base_size",
            "severity": "medium",
            "message": f"Base n={min_base}. Small base — treat as directional.",
        }
    return {
        "check": "base_size",
        "severity": "high",
        "message": f"Base n={min_base}. Very small base — read with caution.",
    }


def check_contradiction(finding: dict, session: dict) -> dict:
    """Check 2 — Within-study contradiction.

    Heuristic: two findings contradict if they reference the same question and
    the same or overlapping banner cuts and their contexts suggest opposite
    directions. We detect this via keyword scan ("higher", "lower", "leads",
    "trails", etc.) on the context field.
    """
    new_rows = set(
        (r.get("question_id"), r.get("response_option"), r.get("banner_group"))
        for r in finding.get("source_rows", [])
    )
    new_context = (finding.get("context") or "").lower()
    new_direction = _infer_direction(new_context)

    contradictions = []
    for prior in session.get("pinned_findings", []):
        prior_rows = set(
            (r.get("question_id"), r.get("response_option"), r.get("banner_group"))
            for r in prior.get("source_rows", [])
        )
        overlap = new_rows & prior_rows
        if not overlap:
            continue
        prior_direction = _infer_direction((prior.get("context") or "").lower())
        if new_direction and prior_direction and new_direction != prior_direction:
            contradictions.append(
                {
                    "finding_id": prior["id"],
                    "context": prior.get("context"),
                }
            )

    if contradictions:
        return {
            "check": "contradiction",
            "severity": "medium",
            "message": f"Appears to contradict {len(contradictions)} earlier finding(s).",
            "detail": contradictions,
        }
    return {"check": "contradiction", "severity": "none", "message": "No contradictions detected."}


def _infer_direction(text: str) -> str | None:
    """Naive direction inference from context text."""
    text = text.lower()
    positive_keywords = ["higher", "lead", "leads", "up", "above", "outperform", "ahead"]
    negative_keywords = ["lower", "trail", "trails", "down", "below", "underperform", "behind"]
    if any(k in text for k in positive_keywords):
        return "positive"
    if any(k in text for k in negative_keywords):
        return "negative"
    return None


def check_against_hypothesis(finding: dict, session: dict) -> dict:
    """Check 3 — Against-hypothesis."""
    obj_ids = finding.get("objective_ids", [])
    matching_hyps = [
        h for h in session.get("hypotheses", [])
        if h.get("objective_id") in obj_ids and h.get("status") == "active"
    ]
    if not matching_hyps:
        return {"check": "against_hypothesis", "severity": "none", "message": "No hypothesis for this objective."}

    # Heuristic: compare direction of finding to hypothesis direction
    finding_direction = _infer_direction((finding.get("context") or "").lower())
    conflicts = []
    for h in matching_hyps:
        h_dir = h.get("direction", "")
        if h_dir in ("a_higher_than_b", "positive") and finding_direction == "negative":
            conflicts.append(h)
        elif h_dir in ("b_higher_than_a", "negative") and finding_direction == "positive":
            conflicts.append(h)

    if conflicts:
        return {
            "check": "against_hypothesis",
            "severity": "info",
            "message": "This finding goes against a hypothesis set for this objective.",
            "detail": [{"hypothesis_id": h["id"], "text": h["text"]} for h in conflicts],
        }
    return {
        "check": "against_hypothesis",
        "severity": "none",
        "message": "Direction aligns with or doesn't contradict hypothesis.",
    }


def check_small_difference(finding: dict, flat: pd.DataFrame) -> dict:
    """Check 4 — Small difference."""
    context = finding.get("context") or ""
    # Try to extract a gap size from the context via regex
    m = re.search(r"(\d+(?:\.\d+)?)\s*(?:pp|percentage points|point gap)", context.lower())
    if not m:
        # Try to compute from source rows — if two rows, take their difference
        source_rows = finding.get("source_rows", [])
        if len(source_rows) == 2:
            vals = []
            bases = []
            for sr in source_rows:
                mask = pd.Series(True, index=flat.index)
                for col, val in sr.items():
                    mask = mask & (flat[col] == val)
                matching = flat[mask]
                if not matching.empty:
                    vals.append(float(matching["value"].iloc[0]) if pd.notna(matching["value"].iloc[0]) else None)
                    bases.append(int(matching["base_n"].iloc[0]) if pd.notna(matching["base_n"].iloc[0]) else None)
            if len(vals) == 2 and None not in vals:
                gap = abs(vals[0] - vals[1])
            else:
                return {
                    "check": "small_difference",
                    "severity": "none",
                    "message": "No explicit gap stated; could not evaluate.",
                }
        else:
            return {
                "check": "small_difference",
                "severity": "none",
                "message": "No explicit gap in context; could not evaluate.",
            }
    else:
        gap = float(m.group(1))

    if gap >= 5:
        return {
            "check": "small_difference",
            "severity": "none",
            "message": f"Gap of {gap}pp is substantive.",
        }
    if gap >= 3:
        return {
            "check": "small_difference",
            "severity": "low",
            "message": f"Gap of {gap}pp is small — treat as directional.",
        }
    return {
        "check": "small_difference",
        "severity": "medium",
        "message": f"Gap of {gap}pp is within likely sampling error.",
    }


def run_all_checks(finding: dict, session: dict, flat: pd.DataFrame) -> list[dict]:
    return [
        check_base_size(finding, flat),
        check_contradiction(finding, session),
        check_against_hypothesis(finding, session),
        check_small_difference(finding, flat),
    ]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--session", required=True)
    parser.add_argument("--finding", required=True)
    parser.add_argument("--flat", required=True)
    args = parser.parse_args()

    with open(args.session) as f:
        session = json.load(f)
    with open(args.finding) as f:
        finding = json.load(f)
    flat = pd.read_csv(args.flat)

    flags = run_all_checks(finding, session, flat)
    print(json.dumps({"flags": flags}, indent=2, default=str))


if __name__ == "__main__":
    main()
