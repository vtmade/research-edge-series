#!/usr/bin/env python3
"""
export.py

Writes final outputs from a session:
- findings_<studyname>.md — pinned findings organised by objective
- tables/finding_<id>.csv — underlying rows per finding
- open_questions.md — unresolved items
- session.json (already saved by session_manager)

Usage:
    python export.py --session <session.json>
"""

import argparse
import json
from pathlib import Path

import pandas as pd


SEVERITY_ICON = {
    "none": "✅",
    "low": "⚠️",
    "info": "ℹ️",
    "medium": "⚠️",
    "high": "❌",
    "unknown": "❓",
}


def export(session_path: str):
    with open(session_path) as f:
        session = json.load(f)

    output_dir = Path(session.get("output_dir", Path(session_path).parent))
    output_dir.mkdir(parents=True, exist_ok=True)
    tables_dir = output_dir / "tables"
    tables_dir.mkdir(exist_ok=True)

    flat_path = session.get("flat_file_path")
    flat = pd.read_csv(flat_path) if flat_path and Path(flat_path).exists() else None

    study_id = session.get("study_id", "study")

    # ---- findings.md ----
    lines = []
    lines.append(f"# Findings — {study_id}")
    lines.append("")
    lines.append(f"Session started: {session.get('created_at')}")
    lines.append(f"Last updated: {session.get('last_updated_at')}")
    lines.append(f"Total findings: {len(session.get('pinned_findings', []))}")
    lines.append("")
    lines.append("---")
    lines.append("")

    # Group findings by objective
    objectives_by_id = {o["id"]: o for o in session.get("objectives", [])}
    findings_by_obj = {}
    for f in session.get("pinned_findings", []):
        for obj_id in f.get("objective_ids", ["unassigned"]):
            findings_by_obj.setdefault(obj_id, []).append(f)

    for obj_id, obj in objectives_by_id.items():
        lines.append(f"## Objective {obj.get('number')} — {obj.get('text')}")
        lines.append("")
        obj_findings = findings_by_obj.get(obj_id, [])

        if not obj_findings:
            lines.append("_No findings pinned for this objective._")
            lines.append("")
            lines.append("---")
            lines.append("")
            continue

        # Hypotheses for this objective
        hyps = [h for h in session.get("hypotheses", []) if h.get("objective_id") == obj_id]
        if hyps:
            lines.append("**Hypotheses:**")
            for h in hyps:
                lines.append(f"- ({h.get('status', 'active')}) {h.get('text')}")
            lines.append("")

        for i, finding in enumerate(obj_findings, start=1):
            lines.append(f"### Finding {obj.get('number')}.{i} — {finding.get('id')}")
            lines.append("")
            lines.append(f"**Observation:** {finding.get('observation', '')}")
            lines.append("")
            lines.append(f"**Context:** {finding.get('context', '')}")
            lines.append("")
            note = finding.get("note")
            if note:
                lines.append(f"**Note:** {note}")
                lines.append("")
            # Flags
            flags = finding.get("flags", [])
            if flags:
                lines.append("**Sanity checks:**")
                for flag in flags:
                    icon = SEVERITY_ICON.get(flag.get("severity", "none"), "❓")
                    name = flag.get("check", "").replace("_", " ").title()
                    msg = flag.get("message", "")
                    lines.append(f"- {icon} {name}: {msg}")
                lines.append("")
            lines.append(f"_Supporting table: tables/{finding['id']}.csv_")
            lines.append("")
            lines.append("---")
            lines.append("")

            # Write supporting table
            if flat is not None:
                source_rows = finding.get("source_rows", [])
                if source_rows:
                    mask = pd.Series(False, index=flat.index)
                    for sr in source_rows:
                        rm = pd.Series(True, index=flat.index)
                        for col, val in sr.items():
                            rm = rm & (flat[col] == val)
                        mask = mask | rm
                    subset = flat[mask]
                    table_path = tables_dir / f"{finding['id']}.csv"
                    subset.to_csv(table_path, index=False, encoding="utf-8-sig")

    findings_path = output_dir / f"findings_{study_id}.md"
    findings_path.write_text("\n".join(lines), encoding="utf-8")

    # ---- open_questions.md ----
    oq_lines = [f"# Open questions — {study_id}", ""]
    open_qs = session.get("open_questions", [])
    if not open_qs:
        oq_lines.append("_No open questions._")
    else:
        oq_lines.append(f"Total: {len(open_qs)}")
        oq_lines.append("")
        for q in open_qs:
            obj = objectives_by_id.get(q.get("objective_id"), {})
            oq_lines.append(f"- **Objective {obj.get('number', '?')}** — {q.get('text')}")
            if q.get("raised_at"):
                oq_lines.append(f"  _Raised: {q['raised_at']}_")
    open_questions_path = output_dir / f"open_questions_{study_id}.md"
    open_questions_path.write_text("\n".join(oq_lines), encoding="utf-8")

    return {
        "findings_md": str(findings_path),
        "open_questions_md": str(open_questions_path),
        "tables_dir": str(tables_dir),
        "session_json": session_path,
        "total_findings": len(session.get("pinned_findings", [])),
        "total_open_questions": len(open_qs),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--session", required=True)
    args = parser.parse_args()
    result = export(args.session)
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
