#!/usr/bin/env python3
"""
session_manager.py

Load, save, initialise, and inspect session state for tidy-data-analysis.

Usage:
    python session_manager.py init --flat <path> --study-id <id> --output-dir <dir>
    python session_manager.py load --session <session.json>
    python session_manager.py summary --session <session.json>
    python session_manager.py save --session <session.json> --update <updates.json>
"""

import argparse
import json
import os
import sys
import tempfile
from datetime import datetime
from pathlib import Path


SESSION_VERSION = "1.0"


def init_session(flat_path: str, study_id: str, output_dir: str) -> dict:
    session = {
        "version": SESSION_VERSION,
        "study_id": study_id,
        "flat_file_path": str(Path(flat_path).absolute()),
        "output_dir": str(Path(output_dir).absolute()),
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "last_updated_at": datetime.now().isoformat(timespec="seconds"),
        "objectives": [],
        "hypotheses": [],
        "question_banner_mapping": {},
        "analytical_moves": [],
        "pinned_findings": [],
        "open_questions": [],
        "skipped_findings": [],
        "session_log": [
            {
                "timestamp": datetime.now().isoformat(timespec="seconds"),
                "event": "session_started",
            }
        ],
    }
    return session


def save_session(session: dict, path: str):
    """Write atomically via temp file + rename."""
    session["last_updated_at"] = datetime.now().isoformat(timespec="seconds")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="w", dir=path.parent, delete=False, suffix=".tmp", encoding="utf-8"
    ) as tmp:
        json.dump(session, tmp, indent=2, default=str)
        tmp_path = tmp.name
    os.replace(tmp_path, path)


def load_session(path: str) -> dict:
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def summarise_session(session: dict) -> dict:
    """Return a compact summary of a session for presentation to the analyst."""
    obj_summary = []
    for obj in session.get("objectives", []):
        pinned = [
            f for f in session.get("pinned_findings", []) if obj["id"] in f.get("objective_ids", [])
        ]
        obj_summary.append(
            {
                "number": obj.get("number"),
                "text": obj.get("text"),
                "status": obj.get("status"),
                "pinned_findings": len(pinned),
            }
        )

    moves = session.get("analytical_moves", [])
    return {
        "study_id": session.get("study_id"),
        "flat_file": session.get("flat_file_path"),
        "created_at": session.get("created_at"),
        "last_updated_at": session.get("last_updated_at"),
        "objectives": obj_summary,
        "total_pinned": len(session.get("pinned_findings", [])),
        "open_questions": len(session.get("open_questions", [])),
        "moves_proposed": len(moves),
        "moves_run": sum(1 for m in moves if m.get("status") == "run"),
        "moves_pending": sum(1 for m in moves if m.get("status") in ("proposed", "approved")),
    }


def apply_updates(session: dict, updates: dict) -> dict:
    """
    Apply a partial update to the session. Supports:
      - add_objective, add_hypothesis, add_mapping
      - add_move, update_move
      - add_finding, update_finding
      - add_open_question, add_skipped_finding
      - add_log_event
    """
    now = datetime.now().isoformat(timespec="seconds")

    for op in updates.get("operations", []):
        kind = op["kind"]
        if kind == "add_objective":
            session["objectives"].append(op["payload"])
        elif kind == "add_hypothesis":
            session["hypotheses"].append(op["payload"])
        elif kind == "set_mapping":
            session["question_banner_mapping"][op["objective_id"]] = op["payload"]
        elif kind == "add_move":
            session["analytical_moves"].append(op["payload"])
        elif kind == "update_move":
            for m in session["analytical_moves"]:
                if m["id"] == op["move_id"]:
                    m.update(op["payload"])
                    break
        elif kind == "add_finding":
            session["pinned_findings"].append(op["payload"])
        elif kind == "update_finding":
            for f in session["pinned_findings"]:
                if f["id"] == op["finding_id"]:
                    f.update(op["payload"])
                    break
        elif kind == "add_open_question":
            session["open_questions"].append(op["payload"])
        elif kind == "add_skipped_finding":
            session["skipped_findings"].append(op["payload"])
        elif kind == "update_objective_status":
            for o in session["objectives"]:
                if o["id"] == op["objective_id"]:
                    o["status"] = op["status"]
                    break

        session["session_log"].append(
            {"timestamp": now, "event": op.get("event_name", kind), **{k: v for k, v in op.items() if k not in ("kind", "payload")}}
        )

    return session


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)

    p_init = sub.add_parser("init")
    p_init.add_argument("--flat", required=True)
    p_init.add_argument("--study-id", required=True)
    p_init.add_argument("--output-dir", required=True)

    p_load = sub.add_parser("load")
    p_load.add_argument("--session", required=True)

    p_summary = sub.add_parser("summary")
    p_summary.add_argument("--session", required=True)

    p_save = sub.add_parser("save")
    p_save.add_argument("--session", required=True)
    p_save.add_argument("--update", required=True, help="Path to updates JSON")

    args = parser.parse_args()

    if args.command == "init":
        session = init_session(args.flat, args.study_id, args.output_dir)
        session_path = Path(args.output_dir) / "session.json"
        save_session(session, session_path)
        print(json.dumps({"session_path": str(session_path), "initialised": True}, indent=2))
    elif args.command == "load":
        session = load_session(args.session)
        print(json.dumps(session, indent=2, default=str))
    elif args.command == "summary":
        session = load_session(args.session)
        print(json.dumps(summarise_session(session), indent=2, default=str))
    elif args.command == "save":
        session = load_session(args.session)
        with open(args.update) as f:
            updates = json.load(f)
        session = apply_updates(session, updates)
        save_session(session, args.session)
        print(json.dumps({"saved": True, "events": len(updates.get("operations", []))}, indent=2))


if __name__ == "__main__":
    main()
