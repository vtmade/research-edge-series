# Workflow — step-by-step interaction

Each step is written as an instruction for Claude Code.

---

## Step 1 — Receive the flat file

Ask the analyst:

> "Please share the flat file you'd like to analyse. CSV or Excel, in the schema produced by flatten-crosstab or extract-crosstabs — the long format with columns like question_id, question_text, row_type, response_option, banner_group, banner_value, value, value_type, base_n."

Verify the file has the expected columns. If columns are missing, flag clearly and ask the analyst to confirm the file is a flat export from one of the upstream skills. If they confirm a non-standard schema, ask them to map each required semantic to a column name in their file.

Required semantic columns:
- question_id, question_text
- row_type, response_option
- banner_group, banner_value
- value, value_type
- base_n

---

## Step 2 — Check for an existing session

Check the output directory for a `session.json`. If present:

> "I found an existing session here (started `<date>`, `<n>` findings pinned so far across `<m>` objectives). Resume that session or start fresh?"

If resume: load the session and show the analyst where they left off — which objectives are open, which findings are pinned, which analytical moves are pending approval. If fresh: continue to Step 3.

---

## Step 3 — Collect research objectives

Ask the analyst:

> "Before we dig into the data, what are the research objectives for this study? I'll use these as the organising frame for everything we do — every finding will be tied to one or more objectives.
>
> You can give them to me as a numbered list, a paragraph, or however is easiest. If they're already written up somewhere (a brief, a proposal, a Slack thread), paste them and I'll structure them."

Parse the objectives into a numbered list. Read them back:

> "I've captured the objectives as:
>
> 1. Measure overall brand health and benchmark against category norms
> 2. Identify the top drivers of consideration for the brand
> 3. Compare UAE vs KSA on brand perception and track quarter-on-quarter shifts
> 4. Profile the 'considerers-not-yet-users' segment
>
> Does this match your intent? Edit, reword, add, or remove any before we proceed."

Save the confirmed objectives to the session.

---

## Step 4 — Map questions and banners to each objective

For each objective in turn, do the following.

Scan the `question_text` column of the flat file. Propose candidate questions based on keyword matching, semantic alignment with the objective, and any question IDs the analyst referenced in the objective. Example:

> "**Objective 2: Identify top drivers of consideration.**
>
> Looking at the questions in the dataset, these seem relevant:
>
> - Q7 — 'Which of the following would make you more likely to consider Brand X?'
> - Q8 — 'Rank the factors that most influence your choice of brand'
> - Q12 — 'To what extent do you agree: Brand X offers good value for money'
> - Q13 — 'To what extent do you agree: Brand X is trustworthy'
>
> Confirm which of these should feed this objective, and tell me if there are others I missed."

For banner cuts, ask:

> "Which banner cuts should I pay most attention to for this objective? The banner groups in the file are: Total, Gender, Age, Market, Segment. Any of these worth focusing on, or are they all equally relevant?"

Repeat for each objective. Save the mapping to the session.

---

## Step 5 — Work through objectives in parallel

After mapping, ask:

> "Which objective should we start with? You can jump between them at any time — just say 'switch to objective X' or 'come back to objective 2'."

Show the objective status board:

```
Objective 1: Brand health                     0 findings  not started
Objective 2: Drivers of consideration         0 findings  not started
Objective 3: UAE vs KSA + QoQ shifts          0 findings  not started
Objective 4: Considerers-not-yet-users        0 findings  not started
```

Update this board whenever the analyst switches, pins a finding, or closes an objective.

---

## Step 6 — Analytical loop (per objective)

For the objective the analyst chose, propose a set of analytical moves. See `reference/analytical-moves.md` for the catalogue.

Example proposal:

> "**Objective 3: UAE vs KSA + QoQ shifts** — mapped to Q1, Q3, Q5, Q12.
>
> Here's what I'd suggest we look at:
>
> 1. Compare UAE vs KSA on the main brand metrics (Q1 NET Aware, Q3 NET Top 2 Satisfaction, Q12 agree-trust)
> 2. For each metric, break down by Age within each market — check if one age band is driving the market difference
> 3. Flag any metric where the gap between markets is large (>5pp) or has reversed since last wave
> 4. Check bases per market cut — make sure we're not reading noise
>
> Approve, trim, add, or reorder. Tell me what you want to run."

Run `scripts/analytical_engine.py` with the approved moves. The engine returns tables — not prose. Present each result as a compact table the analyst can scan.

After each result, ask:

> "Worth pinning as a finding? If yes, what's the context — what makes this interesting? And any note you want to add (caveat, hypothesis link, follow-up)?"

If the analyst pins:

1. Record the observation (auto from the table).
2. Record the context (analyst-proposed; skill can suggest).
3. Record the note (free text from analyst, optional).
4. Run sanity checks — base size, within-study contradiction, against-hypothesis, small-difference — via `scripts/sanity_check.py`.
5. Surface any flags to the analyst: "Heads up — base for Age × 18–24 × KSA is n=38 (flagged as small)."
6. Save to session.

If the analyst doesn't pin but the finding seems relevant:

> "Want me to park this as an open question rather than pin it? I'll keep it in a separate list you can come back to."

---

## Step 7 — Hypothesis prompts

At natural moments (after a compact result or before proposing moves), ask:

> "Do you have a prior view on this? For example, do you expect UAE to outperform KSA on awareness, or is this genuinely open? If you have a hypothesis, I'll flag any finding that goes against it."

Capture hypotheses per objective. They drive the against-hypothesis sanity check.

---

## Step 8 — Discovery prompts

Once the analyst has worked through the mapped questions for an objective, ask:

> "We've covered the planned questions for this objective. Want me to look more broadly — other questions in the data where the pattern we just found also shows up? Sometimes the non-obvious finding is where the real story is. Or skip and move on."

If they want to go broader, the skill looks across all questions for similar patterns (e.g., "UAE leads by >5pp") and surfaces what it finds as a compact ranked list for the analyst to investigate.

---

## Step 9 — Session persistence

Session state auto-saves after every pin, every approval, every objective transition. The file is `<output_dir>/session.json`.

At any point the analyst can say "show me where we are" and the skill summarises: objectives status, findings per objective, open questions, flags.

---

## Step 10 — Export

When the analyst says "export" or "we're done for now":

Run `scripts/export.py` to produce:

- **findings_<studyname>.md** — all pinned findings organised by objective. Each finding: observation, context, note, sanity flags.
- **tables/finding_<obj>_<nnn>.csv** — the rows of the flat file the finding draws on. One CSV per finding.
- **open_questions.md** — objectives and questions the analyst flagged but didn't fully resolve.
- **session.json** — the session state for later resume.

Summarise to the analyst:

> "Exported to `<path>`:
>
> - 14 pinned findings across 4 objectives
> - 14 supporting CSV tables
> - 3 open questions flagged for follow-up
> - Session saved; you can resume this any time.
>
> The findings.md is the input for your report work. Each finding has the observation, the context that makes it matter, your note, and any sanity flags."

---

## Edge cases

- **Flat file has unfamiliar schema** — ask the analyst to map columns to semantics before proceeding.
- **Base size zero for a cut** — skip that cut silently; flag once in the session log.
- **Objective can't be mapped to any question** — flag prominently; ask the analyst if they want to add a question, drop the objective, or mark it as "not addressable from this data."
- **Analyst pins a finding with a flag that says high severity** — ask "the base for this is n=18 — want to pin anyway, or skip and note as caveat?"
- **Two pinned findings contradict** — surface the contradiction immediately and ask the analyst which is the primary reading.
- **Analyst hasn't pinned anything on an objective after extensive work** — gently surface: "Nothing pinned on Objective 4 yet — want to review the moves we've run or close it as 'no findings'?"
