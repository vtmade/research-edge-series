# Sanity checks

Four checks run automatically whenever a finding is pinned. Each produces a flag (low, medium, high severity) that attaches to the finding. Flags never block pinning — they just ensure the analyst sees the relevant caveat.

---

## Check 1 — Base size

**Purpose:** Flag findings drawn from bases too small to be reliable.

**Logic:**

For the specific rows of the flat file the finding draws on, take the minimum `base_n` across those rows.

- `base_n >= 50` → no flag
- `30 <= base_n < 50` → **medium severity** ("Base is small")
- `base_n < 30` → **high severity** ("Base is very small; read with caution")

**Flag message:**

> "Base size for this finding is n=<X>. The minimum acceptable for most published findings is n=30; below n=50, differences should be treated as directional only."

**Exceptions:** The analyst can mark a finding as "base-size-acknowledged" to suppress the flag in the export if they've consciously decided to report a small-base finding with a caveat.

---

## Check 2 — Within-study contradiction

**Purpose:** Surface when a new finding contradicts a previously-pinned one.

**Logic:**

For a newly-pinned finding, look across all previously-pinned findings. A contradiction is detected when:

- The same question is referenced
- The same or overlapping banner cuts are involved
- The observations point in opposite directions (one says "UAE > KSA", the other says "KSA > UAE")

The skill uses the observation text and the underlying table rows to detect this — not natural language alone.

**Flag message:**

> "This finding appears to contradict Finding #<N> pinned earlier: '<text>'. Which is the primary reading? Or are the two saying different things that aren't actually in conflict?"

**Handling:** The analyst can:

- Edit one or both findings to reconcile
- Mark both as "complementary, not contradictory" with a note
- Demote one to an open question
- Keep both and acknowledge the tension in the note field

The flag persists in the export as a "review the tension" marker.

---

## Check 3 — Against-hypothesis

**Purpose:** Surface when a finding goes against a hypothesis the analyst set for its objective.

**Logic:**

Only runs if a hypothesis exists for the finding's objective. Compares the direction of the finding to the direction the hypothesis predicted.

**Flag message:**

> "Heads up — this finding goes against the hypothesis you set for this objective: '<hypothesis text>'. That's often where the most interesting findings sit; worth thinking about what it means."

**Handling:** Not a blocker. The analyst decides whether to:

- Update the hypothesis ("we were wrong about this, and here's why")
- Note the disconfirmation in the finding's note
- Investigate further before pinning

This flag is framed as a prompt to think, not a warning.

---

## Check 4 — Small difference

**Purpose:** Flag when the finding's substantive claim rests on a difference that's likely within sampling error.

**Logic:**

If the finding's context describes a gap or comparison (e.g., "UAE 78 vs KSA 65 — 13pp gap"), compute the gap in percentage points (for percent rows) or the absolute difference (for means).

- Gap >= 5pp (or >0.5 for mean on a 1–10 scale) → no flag
- 3pp <= gap < 5pp → **low severity** ("Small gap, interpret as directional")
- Gap < 3pp → **medium severity** ("Gap is within likely sampling error for this base")

**Flag message:**

> "The gap here is <X>pp on a base of n=<Y>. Rough rule of thumb: at this base, differences under 3pp are unlikely to be statistically meaningful. Is the finding worth pinning at this gap size?"

**Handling:** Analyst can keep the finding (often justified — even small gaps can matter in context) or re-cast it as "no meaningful difference, which itself is the finding" or drop.

If significance testing was applied upstream and sig markers are present in the data, Check 4 uses those directly rather than the pp threshold: a sig-tested difference, however small, doesn't get flagged.

---

## How flags appear in the export

In the findings markdown, each pinned finding carries its flags:

```markdown
### Finding 2.4 — UAE leads KSA on NET Aware

**Observation:** NET Aware (Q1): UAE = 78%, KSA = 65%. Base: UAE n=600, KSA n=400.
**Context:** 13pp gap; largest cross-market gap across the brand-health questions.
**Note:** Consistent with prior qual — UAE respondents recalled more ad touchpoints.

**Flags:**
- ✅ Base size OK (n=400+)
- ✅ No contradictions with other pinned findings
- ⚠️ Against-hypothesis: "UAE usually leads KSA — expected, but by a larger margin"
- ✅ Gap size substantive (>5pp)
```

---

## Severity legend

- ✅ Check passed, no flag
- ⚠️ Low/medium severity — informational, worth the analyst's awareness
- ❌ High severity — the finding should be reviewed before it enters the report

The analyst makes the final call in every case. Flags are signals, not rules.
