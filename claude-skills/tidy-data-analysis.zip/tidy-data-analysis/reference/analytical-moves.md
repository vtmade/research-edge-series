# Analytical moves — the catalogue

The skill proposes analytical moves drawn from this catalogue. Each move is a deterministic query against the flat file, executed by `analytical_engine.py`. The move names here are the internal identifiers; the skill translates them to natural language when proposing to the analyst.

---

## Move: `compare_banner_values`

Compare a specific question × response across values of a banner group.

**Parameters:**
- `question_id` — which question
- `response_option` or `row_type + response_option` — which row (e.g., "NET Aware", "Top of mind", a mean row)
- `banner_group` — which banner group to compare across (e.g., Market)

**Output:** table with one row per banner value, showing value + base_n.

**Example proposal:** "Compare NET Aware (Q1) across Market (UAE vs KSA)"

---

## Move: `drilldown_within_cut`

Within a single banner value, show the full distribution for a question.

**Parameters:**
- `question_id`
- `banner_group + banner_value` — the cut to drill into

**Output:** table of every response row for that question × cut, with value + base_n.

**Example proposal:** "Show the full Q3 (Satisfaction) distribution within KSA"

---

## Move: `crosscut_within_group`

For a question, show it by one banner group, then within each banner value of that group, show another banner group.

**Parameters:**
- `question_id`
- `primary_banner_group`
- `secondary_banner_group`
- `response_option` (optional; if not provided, returns all rows)

**Output:** table with outer rows = primary banner values, inner rows = secondary banner values, columns = response values.

**Example proposal:** "Look at NET Top 2 Satisfaction by Market × Age"

---

## Move: `rank_gaps`

Across many questions, rank the biggest differences between two specific banner values.

**Parameters:**
- `banner_group`
- `banner_value_a`, `banner_value_b` — the two cuts to compare
- `threshold` (optional) — minimum gap to include (default: 5pp)
- `response_filter` (optional) — e.g., "only NET rows", "only percent rows"

**Output:** table of questions × response, with gap (a - b), ranked by absolute gap.

**Example proposal:** "Where do UAE and KSA diverge most across all questions? Rank by gap size, NET rows only, threshold 5pp."

---

## Move: `find_reversals`

Find questions where the direction of difference between two cuts is opposite to what's typical across the dataset.

**Parameters:**
- `banner_group`
- `banner_value_a`, `banner_value_b`
- `typical_direction` — analyst specifies (e.g., "UAE usually leads KSA")

**Output:** table of questions where `banner_value_b > banner_value_a`, despite the typical pattern.

**Example proposal:** "UAE usually leads KSA — find the questions where KSA leads instead."

---

## Move: `outlier_cut`

For a given question × response, find banner cuts that are unusually high or low compared to the overall distribution.

**Parameters:**
- `question_id`
- `response_option` or `row_type + response_option`
- `method` — `std_dev` (default: >1.5 SD from mean) or `iqr` (outside 1.5 × IQR)

**Output:** table of banner cuts flagged as outliers, with value + base_n.

**Example proposal:** "Which age/market cuts are outliers on NET Top 2 Satisfaction (Q3)?"

---

## Move: `base_size_scan`

Scan the data for cuts where base_n is below a threshold.

**Parameters:**
- `threshold` (default: 50)

**Output:** table of (question × banner cut) with base_n below threshold.

**Example proposal:** "Flag any cuts with base < 50 so we don't read too much into them."

---

## Move: `cross_question_check`

For a list of related questions, show the values for a single cut side-by-side to check for coherence.

**Parameters:**
- `question_ids` — list of questions
- `banner_group + banner_value` — the cut
- `response_option` (optional) — e.g., "NET Top 2" or "Mean"

**Output:** table with one row per question, showing the selected value + base_n.

**Example proposal:** "Check coherence: NET Top 2 across Q3, Q12, Q13, Q14 (all brand-agree questions) within Total."

---

## Move: `response_ranking`

Within a question, rank response options by value across a specific banner cut.

**Parameters:**
- `question_id`
- `banner_group + banner_value` (default: Total × Total)
- `top_n` (optional; default: all)

**Output:** sorted table of response options.

**Example proposal:** "What are the top 5 brands mentioned on Q2 (multi-response) within UAE?"

---

## Move: `scale_shape`

For scale questions, summarise the shape of the distribution — skewed, bimodal, concentrated.

**Parameters:**
- `question_id`
- `banner_group + banner_value` (default: Total × Total)

**Output:** the full scale distribution + simple shape descriptors (mean, median, top-box %, bottom-box %, spread).

**Example proposal:** "Show the shape of Q3 satisfaction — is it top-heavy, middle-heavy, bimodal?"

---

## Move: `contradictions_check`

Across all pinned findings, check for contradictions or tensions.

**Parameters:**
- (none — runs on pinned findings)

**Output:** table of pairs of findings that appear to contradict each other, with an explanation.

**Example proposal:** "Let me run a contradictions check across everything we've pinned."

---

## How the skill proposes moves

Given an objective + its mapped questions + banner cuts, the skill proposes 3–6 moves that together address the objective. It does not propose all possible moves — the catalogue is large, but proposing too many is noise.

The skill biases toward:

1. **Moves that directly answer the objective** (e.g., if objective is "compare UAE vs KSA", `compare_banner_values` with Market is top)
2. **Moves that check coherence** (e.g., `cross_question_check` across related questions)
3. **Moves that check rigour** (e.g., `base_size_scan` before deep interpretation)
4. **Moves that surface surprises** (e.g., `find_reversals`, `outlier_cut`)

The analyst sees the proposals with a short rationale for each and approves/trims before anything runs.
