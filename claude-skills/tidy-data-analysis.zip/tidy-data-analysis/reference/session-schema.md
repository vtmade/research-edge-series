# Session schema

The `session.json` file preserves the full state of an analysis session so it can be resumed across sittings. It is auto-saved after every meaningful event (pin, approval, objective transition).

---

## Top-level structure

```json
{
  "version": "1.0",
  "study_id": "brand_health_Q3_2025",
  "flat_file_path": "/path/to/flat_brand_health_Q3_2025_long.csv",
  "created_at": "2026-04-24T10:15:00",
  "last_updated_at": "2026-04-24T14:32:10",
  "objectives": [...],
  "hypotheses": [...],
  "question_banner_mapping": {...},
  "analytical_moves": [...],
  "pinned_findings": [...],
  "open_questions": [...],
  "skipped_findings": [...],
  "session_log": [...]
}
```

---

## objectives

```json
"objectives": [
  {
    "id": "obj_1",
    "number": 1,
    "text": "Measure overall brand health and benchmark against category norms",
    "status": "in_progress",
    "finding_count": 3
  },
  {
    "id": "obj_2",
    "number": 2,
    "text": "Identify the top drivers of consideration for the brand",
    "status": "not_started",
    "finding_count": 0
  }
]
```

`status`: `not_started` | `in_progress` | `findings_pinned` | `closed_no_findings` | `closed_done`

---

## hypotheses

```json
"hypotheses": [
  {
    "id": "hyp_1",
    "objective_id": "obj_3",
    "text": "UAE will outperform KSA on all brand health metrics",
    "direction": "uae_higher_than_ksa",
    "status": "active"
  }
]
```

`status`: `active` | `confirmed` | `disconfirmed` | `mixed`

---

## question_banner_mapping

```json
"question_banner_mapping": {
  "obj_1": {
    "questions": ["Q1", "Q3", "Q12", "Q13"],
    "banner_groups_focus": ["Total", "Market"]
  },
  "obj_2": {
    "questions": ["Q7", "Q8", "Q12", "Q13"],
    "banner_groups_focus": ["Total", "Age", "Segment"]
  }
}
```

---

## analytical_moves

Every move proposed, approved, run, or skipped.

```json
"analytical_moves": [
  {
    "id": "move_001",
    "objective_id": "obj_3",
    "type": "compare_banner_values",
    "parameters": {
      "question_id": "Q1",
      "response_option": "NET Aware",
      "banner_group": "Market"
    },
    "proposed_at": "2026-04-24T10:30:00",
    "status": "run",
    "result_summary": "UAE=78, KSA=65"
  }
]
```

`status`: `proposed` | `approved` | `run` | `skipped` | `rejected`

---

## pinned_findings

```json
"pinned_findings": [
  {
    "id": "finding_obj3_001",
    "objective_ids": ["obj_3"],
    "observation": "NET Aware (Q1): UAE = 78%, KSA = 65%. Base: UAE n=600, KSA n=400.",
    "context": "13pp gap; largest cross-market gap across the brand-health questions.",
    "note": "Consistent with prior qual — UAE respondents recalled more ad touchpoints.",
    "source_rows": [
      {"question_id": "Q1", "row_type": "net", "response_option": "NET Aware", "banner_group": "Market", "banner_value": "UAE"},
      {"question_id": "Q1", "row_type": "net", "response_option": "NET Aware", "banner_group": "Market", "banner_value": "KSA"}
    ],
    "move_id": "move_001",
    "flags": [
      {"check": "base_size", "severity": "none"},
      {"check": "contradiction", "severity": "none"},
      {"check": "against_hypothesis", "severity": "info", "message": "Direction matches hypothesis, but gap is larger than expected."},
      {"check": "small_difference", "severity": "none"}
    ],
    "pinned_at": "2026-04-24T10:35:00"
  }
]
```

---

## open_questions

Parked findings that weren't pinned but the analyst wants to revisit.

```json
"open_questions": [
  {
    "id": "open_001",
    "objective_id": "obj_2",
    "text": "Q12 trust score doesn't move across segments — why?",
    "raised_at": "2026-04-24T11:15:00",
    "status": "open"
  }
]
```

---

## skipped_findings

Observations the analyst explicitly chose not to pin, with a reason. Kept for audit so that re-examining the data in a later session doesn't surface the same thing again.

```json
"skipped_findings": [
  {
    "move_id": "move_012",
    "reason": "Gap is within rounding; not worth reporting.",
    "skipped_at": "2026-04-24T11:45:00"
  }
]
```

---

## session_log

Human-readable trace of the session for audit.

```json
"session_log": [
  {"timestamp": "2026-04-24T10:15:00", "event": "session_started"},
  {"timestamp": "2026-04-24T10:18:00", "event": "objectives_captured", "count": 4},
  {"timestamp": "2026-04-24T10:30:00", "event": "move_proposed", "move_id": "move_001"},
  {"timestamp": "2026-04-24T10:32:00", "event": "move_approved", "move_id": "move_001"},
  {"timestamp": "2026-04-24T10:32:30", "event": "move_run", "move_id": "move_001"},
  {"timestamp": "2026-04-24T10:35:00", "event": "finding_pinned", "finding_id": "finding_obj3_001"}
]
```

---

## Invariants

- Every pinned finding has at least one objective_id.
- Every pinned finding has source_rows pointing back to flat file rows.
- Every analytical move has status and (if run) a result_summary.
- last_updated_at is refreshed on every save.
- The file is rewritten atomically (write to temp, move) to avoid corruption.
