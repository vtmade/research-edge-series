---
name: tidy-data-analysis
description: Analyse a flat-format survey dataset (produced by flatten-crosstab or extract-crosstabs) to work through research objectives, test hypotheses, and pin findings that will feed the final report. This is not a report-writing skill. The skill helps the analyst discover what matters in the data, sanity-check findings as they go, and export a structured set of findings plus underlying tables for report-writing. Use whenever the user has a flat survey data file and wants to work through insights, findings, or analytical interpretation. Trigger on /analyse-flat or when the user says "analyse this flat file", "help me find insights in this crosstab", "work through my research objectives on this data", "what does this data tell me", or similar.
---

# tidy-data-analysis

A thinking partner for the analytical stage between a flat survey dataset and a final report. The skill does not write the report. It helps the analyst answer research objectives, test hypotheses, discover non-obvious patterns, decide what's worth reporting, and pin findings with the evidence that supports them.

## When to use this skill

Use after `flatten-crosstab` or `extract-crosstabs` has produced a flat file. The input is a tidy file with one row per (question × response × banner cut) — the standard schema across the framework.

Do not use when:

- The data is raw respondent-level — use `extract-crosstabs` first to tabulate
- The output needed is the report itself — this skill stops at pinned findings, not prose
- The analysis is multivariate (driver analysis, regression, segmentation, clustering, factor analysis) — that's Path B territory; this skill is for univariate and bivariate insight work

Typical triggers:

- `/analyse-flat` slash command
- "analyse this flat file"
- "help me find insights in this crosstab"
- "work through my research objectives on this data"
- "what does this data tell me about X"

## Core principle

The LLM interprets. Python computes.

Every observation the skill produces comes from a deterministic pandas query against the flat file. The LLM's role is: proposing which cuts to examine, reading the tables, surfacing patterns worth a human eye, and structuring findings. It does not generate findings of its own. Every pinned finding has an auto-populated observation (from Python), a context proposal (editable), and the analyst's own note.

## Workflow

Follow `reference/workflow.md` step-by-step.

**Summary of stages:**

1. **Receive the flat file** and confirm its structure (expected schema from flatten-crosstab / extract-crosstabs).
2. **Check for an existing session.** Offer to resume or start fresh.
3. **Collect research objectives** from the analyst (free text, numbered list).
4. **Map questions and banners to each objective** interactively. Skill proposes candidates by reading question_text; analyst confirms, trims, adds.
5. **Work through objectives in parallel.** Analyst picks which to tackle, can jump between them.
6. **For each objective:** skill proposes analytical moves (comparisons, cuts, patterns to check). Analyst approves what to run. Python runs them. Skill surfaces results. Analyst pins findings.
7. **Sanity-check every pin** automatically (base size, contradiction, hypothesis, small-diff).
8. **Continuously save session state** so work can resume across sittings.
9. **On request: export** findings (markdown) + underlying tables (CSV per pin) + session log.

## Output schema

The skill's output is not the flat file — the flat file is the *input*. The output is a folder containing:

- `findings_<studyname>.md` — pinned findings, organised by objective
- `tables/finding_<obj>_<nnn>.csv` — the rows from the flat file each finding draws on
- `session.json` — full session state (for resume + audit)
- `open_questions.md` — objectives or questions the analyst flagged but didn't fully resolve

## Non-negotiables

- **The skill never writes findings.** It computes observations, proposes contexts, asks the analyst to pin with their own note. No auto-generated prose insights.
- **Every observation is traceable.** Each pin references the exact rows of the flat file it draws on.
- **Sanity checks run on every pin.** Small base, contradiction, hypothesis conflict, and small-difference flags are surfaced automatically.
- **Objectives are the organising frame.** Every finding attaches to one or more objectives. "Interesting but unmapped" findings are held in a separate bucket for the analyst to decide on later.
- **Session state persists.** Analytical work spans multiple sittings. The skill is built for that.
- **Python computes; the LLM interprets.** No direct transcription of numbers from the flat file by the LLM.

## Dependencies

- Python 3.10+
- `pandas`
- `numpy`

Install if missing:

```bash
pip install pandas numpy --break-system-packages
```

## Files in this skill

```
tidy-data-analysis/
├── SKILL.md                          # This file
├── README.md                         # Analyst-facing install + usage
├── reference/
│   ├── workflow.md                   # Step-by-step interaction
│   ├── analytical-moves.md           # Catalogue of cuts/comparisons the skill can propose
│   ├── sanity-checks.md              # The four auto-checks, defined precisely
│   └── session-schema.md             # session.json structure
└── scripts/
    ├── session_manager.py            # Load/save/resume session state
    ├── analytical_engine.py          # Executes analytical moves against the flat file
    ├── sanity_check.py               # Runs the four checks on a pinned finding
    └── export.py                     # Writes findings.md + tables/ + open_questions.md
```
