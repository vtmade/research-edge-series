# Validation specification

Four checks, all run by default. Failures are flagged in the validation report but do not block output.

---

## Check 1 — Base reconciliation

**What it checks:** Every banner value in the flat output has a `base_n` that matches the banner plan.

**How it runs:**

For each unique combination of `banner_group` × `banner_value` in the flat file:

1. Look up the expected base from the banner plan
2. Compare to the `base_n` in the flat file
3. Flag if mismatched or missing

**Threshold:** Exact match required. Any mismatch is flagged.

**Common failure modes:**

- Weighted base applied where unweighted was expected (or vice versa)
- Banner value not present in the banner plan (new cut added by agency)
- Banner plan value not present in the file (cut was dropped)

---

## Check 2 — Percentage sum check

**What it checks:** For every question where `value_type = percent`, the values within each `question_id × banner_group × banner_value` sum to 100 (±1%).

**How it runs:**

For each group:

1. Filter to `row_type = response` only (exclude NETs, subtotals, means, medians)
2. Sum the `value` column
3. Check against 100 (±1)

**Threshold:** ±1 percentage point tolerance. Rounding in agency deliverables often produces 99 or 101; these are not flagged. Anything outside ±1 is flagged.

**Exclusions:**

- Multi-response questions (where sum can exceed 100) — flagged separately as "multi-response, not summed"
- Numeric/mean questions (where `value_type ≠ percent`) — skipped
- Questions with any null values in the responses — flagged as "incomplete responses, sum check skipped"

**Detection of multi-response questions:**

- Question text contains keywords: "select all", "multiple", "any of", "all that apply"
- Or: sum exceeds 100 by more than 10 percentage points consistently across banner cuts
- Detection rules are heuristic — can be overridden by the analyst during inspection

---

## Check 3 — NET integrity

**What it checks:** For each question, any NET row is greater than or equal to the sum of its component response rows within the same banner cut.

**How it runs:**

For each `question_id × banner_group × banner_value`:

1. Identify the NET row (`row_type = net`)
2. Identify the component response rows that NET aggregates (inferred from row position or labelling)
3. Check: NET value ≥ sum of components

**Threshold:** NET should be exactly equal to or greater than the sum. A NET lower than its components is almost always an error. A 1pp overshoot can occur due to rounding in source and is flagged as low-severity.

**Caveats:**

- The skill infers NET composition from row order (NET usually follows its components) — imperfect
- If NET composition is ambiguous, flag as "NET composition unclear, check skipped" rather than report a false failure

---

## Check 4 — Completeness

**What it checks:** Every question and banner cut declared in the banner plan appears in the flat output.

**How it runs:**

1. Build expected set from the banner plan: every (question_id × banner_group × banner_value)
2. Build actual set from the flat output
3. Report any missing combinations

**Threshold:** Exact match required.

**Common failure modes:**

- Question was asked to a sub-sample and is correctly absent from some cuts (should be declared in banner plan as conditional)
- Agency dropped a question in a wave without updating the banner plan
- Skill failed to parse a question during inspection (upstream bug)

---

## Validation report format

Written as markdown to `validation_<inputname>.md`. Structure:

```markdown
# Validation report — <filename>

Run at: <timestamp>
Flat file: <path>
Banner plan: <path, or "not provided">

---

## Check 1 — Base reconciliation

Status: ✅ Passed | ⚠️ Issues flagged | ❌ Failed

- <banner_group>: <banner_value> — expected n=<X>, got n=<Y> <status>
- ...

---

## Check 2 — Percentage sum check

Status: ✅ | ⚠️ | ❌

- Q1 × Gender × Male: sum = 100.0 ✅
- Q14 × Age × 25-34: sum = 97.2 ⚠️ (outside ±1 tolerance)
- ...

---

## Check 3 — NET integrity

Status: ✅ | ⚠️ | ❌

- Q14 × Age × 25-34: NET TOP 2 = 45, components sum = 46 ⚠️ (NET 1pp below components)
- ...

---

## Check 4 — Completeness

Status: ✅ | ⚠️ | ❌

- Missing from output: Q22 × Market × KSA
- Missing from banner plan: Q8 × Segment × HNW (present in file but not declared)
- ...

---

## Summary

- Total questions: 37
- Total banner cuts: 10
- Total rows in flat file: 2,847
- Passed all four checks: ✅
- Flagged issues: 2 (low severity)
- Recommended action: <text>
```

---

## Severity levels

Every flagged issue is assigned a severity:

- **Low** — Likely rounding, cosmetic, or heuristic detection limit. Safe to proceed with caution.
- **Medium** — Substantive mismatch worth analyst review before using the data.
- **High** — Indicates a probable error in the source file or banner plan. Analysis should not proceed until resolved.

The final line of the report states the highest severity encountered.
