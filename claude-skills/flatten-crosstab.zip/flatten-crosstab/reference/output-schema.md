# Output schema

Exact specification of the flat file's columns, types, and allowed values.

---

## Long format (default)

One row per (question × response × banner_group × banner_value).

| Column | Type | Description | Allowed values / notes |
|---|---|---|---|
| `source_sheet` | string | Name of the sheet in the original file | Any string |
| `question_id` | string | Auto-generated if absent in source | `Q1`, `Q2`, ... |
| `question_text` | string | Verbatim question text from source | Any string; trimmed of whitespace |
| `row_type` | string | Classification of the row | `response` \| `net` \| `subtotal` \| `mean` \| `median` |
| `response_option` | string | The row label (response option or NET/mean label) | Any string |
| `banner_group` | string | Banner group name | `Total`, `Gender`, `Age`, `Market`, etc. |
| `banner_value` | string | Specific cut within the banner group | `Total`, `Male`, `Female`, `18-24`, etc. |
| `value` | float | The numeric value | Stripped of sig markers if analyst chose strip |
| `value_type` | string | Kind of measure in `value` | `percent` \| `mean` \| `count` |
| `base_n` | integer | Base size for this banner value | From banner plan; null if not available |
| `sig_markers` | string | Significance letters, if preservation was chosen | `A`, `AB`, `ab`, etc.; null otherwise |

### Row-type classification rules

Applied in order — first match wins:

1. Row label contains `NET` → `net`
2. Row label contains `Total` (as a row, not banner) → `subtotal`
3. Row label matches `Mean`, `Average`, `Avg`, `Mean score` → `mean`
4. Row label matches `Median` → `median`
5. Otherwise → `response`

Classification is case-insensitive. Multiple patterns can be added to `reference/row_type_patterns.yaml` if agencies use non-standard labels.

### Value parsing rules

- Integers and floats are parsed as-is
- Percentages with `%` symbol: strip the symbol, keep as number (14% → 14)
- Percentages expressed as decimals (0.14) are **not** rescaled — analyst confirms at inspection
- Blank cells → null (not 0)
- `-` or `*` or `N/A` → null
- Sig markers: stripped or preserved per runtime choice

---

## Wide format (optional)

Pivot table: questions × responses as rows, banner values as columns.

| Column | Type | Description |
|---|---|---|
| `source_sheet` | string | Sheet name |
| `question_id` | string | Question identifier |
| `question_text` | string | Question text |
| `row_type` | string | `response` \| `net` \| `subtotal` \| `mean` \| `median` |
| `response_option` | string | Row label |
| `value_type` | string | `percent` \| `mean` \| `count` |
| `<banner_group>_<banner_value>` | float | One column per banner cut (e.g., `Gender_Male`, `Age_18-24`) |
| `<banner_group>_<banner_value>_base_n` | integer | Base size for each cut |

Wide format is appropriate for human inspection and wave-on-wave comparisons. Long format is preferred for LLM reasoning and most pipeline analysis.

---

## Data dictionary output

The companion dictionary file mirrors this schema as a CSV for downstream tools. Columns:

| Column | Type | Description |
|---|---|---|
| `column_name` | string | Name of column in the flat file |
| `type` | string | Data type |
| `description` | string | What the column represents |
| `allowed_values` | string | Enum values or format constraints |
| `notes` | string | Any caveats from the run |

---

## Null-handling conventions

- Numeric nulls: empty string in CSV, NaN in pandas
- String nulls: empty string in CSV, NaN in pandas
- Never use sentinel values like `-999` or `NA` as strings in numeric columns

---

## Encoding and locale

- Output CSVs are UTF-8 with BOM (for Excel compatibility)
- Decimal separator: `.` (period)
- Thousands separator: none
- Date fields (if present): ISO 8601 (`YYYY-MM-DD`)
