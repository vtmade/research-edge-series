# Workflow — step-by-step interaction

This is the exact sequence the skill follows when invoked. Each step is written as an instruction to Claude Code.

---

## Step 1 — Receive the crosstab file(s)

Ask the analyst:

> "Please share the crosstab file (or files) you'd like to flatten. XLSX, XLS, and CSV are all supported. If the file is already in the workspace, just tell me the path."

Accept:

- A single file path
- Multiple file paths (process each one separately, unless the analyst wants them merged)
- A folder path (list contents, ask which files to include)

Do not proceed until at least one valid file is provided.

---

## Step 2 — Ask for supporting context

Ask the analyst for three specific context documents. Do not ask for the full questionnaire.

> "Before I flatten the file, I need some context about the study. Please share what you have:
>
> 1. **Banner plan or banner map** — which banner groups and values should appear in the columns, and what are their expected base sizes?
> 2. **Base definitions** — is the 'Total' column based on all respondents, or screened-in only? Are any questions asked to sub-samples?
> 3. **Weighting note** — were weights applied? If so, which weighting scheme?
>
> If you have anything else that would help — a significance testing legend, a variable list, notes on conventions — share that too. If you don't have all of these, share what you have and I'll flag any gaps."

Record what the analyst provides. If the banner plan is missing, flag it as a risk but do not block. Document missing context in the validation report.

---

## Step 3 — Ask for three runtime choices

Ask the analyst in a single grouped question:

> "Three quick choices before I inspect the file:
>
> 1. **Output shape** — long format (one row per cell, best for LLM and pipelines), wide format (banner as columns, best for reading), or both?
> 2. **Significance markers** — if there are letters like A/B/a/b marking significance in the cells, should I strip them, preserve them in a separate column, or keep them inline with the values?
> 3. **Output location** — default is a `flattened/` folder alongside the input file. Confirm or specify a different path."

Record the choices. Defaults if the analyst is unsure:

- Output shape: **long**
- Sig markers: **strip, preserve in separate `sig_markers` column**
- Output location: **`./flattened/`**

---

## Step 4 — Inspect the file

Run `scripts/inspect_crosstab.py` with the file path as an argument. The script returns a structured inspection summary covering:

- Sheet names
- Detected banner rows (row indices with merged cells or banner-like content)
- Detected question column (usually column A)
- Sample of questions and response options found
- Base size locations (if detected)
- Any ambiguities the script couldn't resolve automatically

Example invocation:

```bash
python scripts/inspect_crosstab.py /path/to/crosstab.xlsx
```

---

## Step 5 — Present the proposed interpretation

Show the inspection output to the analyst as a readable summary. Example:

> "Here's how I'm reading the file. Please confirm or correct before I flatten:
>
> **File:** brand_tracker_Q3_2025.xlsx
> **Sheets found:** 12 (all will be flattened into a single consolidated output)
>
> **Banner structure (rows 1–3):**
> - Row 1: Banner group — Total, Gender, Age, Market
> - Row 2: Banner value — Total, Male, Female, 18-24, 25-34, 35-44, 45-54, 55+, UAE, KSA
> - Row 3: Base sizes — (n=1000), (n=500), (n=500), (n=200), (n=250), (n=200), (n=200), (n=150), (n=600), (n=400)
>
> **Row structure:**
> - Question text in column A, response options indented below each question
> - 37 questions detected across all sheets
> - NET rows detected (labelled 'NET TOP 2', 'NET BOTTOM 2')
> - Mean rows detected (labelled 'Mean')
>
> **Ambiguities flagged:**
> - Sheet 'S4_Drivers' has a different banner structure (4 rows of headers instead of 3). Please confirm how to interpret row 4.
> - Column L on sheet 'S7_Attitudes' has no banner label. Should I ignore it, or label it manually?
>
> Confirm this reading, or tell me what to adjust."

Wait for explicit confirmation. Do not proceed on ambiguity.

---

## Step 6 — Flatten

Run `scripts/flatten.py` with the confirmed interpretation passed as a config JSON or CLI arguments. The script:

1. Reads each sheet
2. Forward-fills question text down response rows
3. Melts the banner columns into rows
4. Strips or preserves sig markers per analyst choice
5. Classifies each row as `response`, `net`, `subtotal`, `mean`, or `median`
6. Attaches `base_n` from the banner plan
7. Writes the flat file to the output location (CSV + Excel)

Example invocation:

```bash
python scripts/flatten.py \
  --input /path/to/crosstab.xlsx \
  --config /path/to/run_config.json \
  --output-dir /path/to/flattened/
```

---

## Step 7 — Validate

Run `scripts/validate.py` against the flat file and the banner plan. All four checks run:

1. Base reconciliation
2. Percentage sum check
3. NET integrity
4. Completeness

The script writes a validation report to the output folder as markdown.

Example invocation:

```bash
python scripts/validate.py \
  --flat /path/to/flattened/flat_crosstab.csv \
  --banner-plan /path/to/banner_plan.csv \
  --output /path/to/flattened/validation_crosstab.md
```

---

## Step 8 — Write companion artefacts

The flatten script already writes CSV + Excel of the flat file. Additionally generate:

- **Data dictionary** — a CSV listing every column in the flat output, its type, allowed values, and notes. Generated from `reference/output-schema.md` and the actual output.
- **Validation report** — already written by `validate.py`.

---

## Step 9 — Summarise to the analyst

End the run with a clear, readable summary. Example:

> "Done. Here's what I produced in `/path/to/flattened/`:
>
> - **flat_brand_tracker_Q3_2025.csv** and **.xlsx** — 2,847 rows, 11 columns
> - **dictionary_brand_tracker_Q3_2025.csv** — column reference
> - **validation_brand_tracker_Q3_2025.md** — all four checks
>
> **Validation summary:**
> - ✅ Base reconciliation passed for all 10 banner values
> - ✅ Percentage sums within ±1% for all questions
> - ⚠️ NET integrity flagged on Q14 — NET TOP 2 is 1pp lower than sum of components. Likely rounding, but worth a glance.
> - ✅ All 37 questions from the banner plan appear in the output
>
> Want me to walk through the flagged NET on Q14, or is this ready for analysis?"

---

## Edge cases

- **File unreadable or corrupt** — stop and tell the analyst. Do not attempt to flatten.
- **Banner plan contradicts file** — flag the contradiction explicitly, ask the analyst which is correct.
- **Mixed value types in one question** (some % rows, some mean rows) — classify correctly using `row_type`; do not force everything into one `value_type`.
- **Multiple weights applied** — flag in the validation report; ask the analyst to confirm which weight the flat output should reflect.
- **Non-survey tables mixed in** (sample sizes, methodology notes, cover pages) — skip these sheets; list them in the validation report.
