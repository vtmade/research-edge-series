---
name: flatten-crosstab
description: Convert agency quantitative survey crosstab deliverables (XLSX/XLS/CSV) into a flat, self-describing format for downstream LLM and Python analysis. Use this skill whenever the user wants to flatten, reshape, tidy, or convert a crosstab, banner table, or DP output into a long/wide flat format with validation. Trigger on /flatten-crosstab or when the user mentions flattening a crosstab, tab file, banner report, or DP deliverable. Not for raw respondent-level data — use only when the input is already an aggregated crosstab.
---

# flatten-crosstab

Convert a quantitative survey crosstab into a flat, self-describing format that is unambiguous for both LLM reasoning and Python computation. This skill is hybrid (LLM-guided inspection + deterministic Python execution) and interactive (always confirms structure with the analyst before flattening).

## When to use this skill

Use when the user has received a crosstab deliverable from an agency or DP team and wants to prepare it for analysis. The input is an aggregated table — not raw respondent-level data. If the input is raw respondent data, direct the user to a raw-data extraction skill instead.

Typical triggers:

- `/flatten-crosstab` slash command
- "flatten this crosstab"
- "convert this banner table to flat format"
- "tidy this DP output"
- "reshape this tab file for analysis"

## Core principle

The LLM interprets. Python computes.

The skill uses the LLM to read the crosstab's structure, propose an interpretation, and confirm it with the analyst. Python then executes the flattening deterministically. This preserves verifiability, validity, and consistency — every number in the output traces back to a source cell.

## Workflow

Follow `reference/workflow.md` step-by-step. The workflow is non-negotiable because each step de-risks the next.

**Summary of stages:**

1. **Receive the crosstab file(s)** from the analyst.
2. **Ask for supporting context** — banner plan, base definitions, weighting note. Accept whatever the analyst provides. Do not block if some are missing; flag the risk instead.
3. **Ask the analyst three runtime choices:**
   - Output shape — long, wide, or both
   - Significance marker handling — strip, preserve separately, or keep inline
   - Output location — default is `./flattened/` alongside the input file
4. **Inspect the file** using `scripts/inspect_crosstab.py`. The script surfaces the banner structure, question column, response rows, base sizes, and any ambiguities.
5. **Present the proposed interpretation** to the analyst as a readable summary. Wait for confirmation or corrections before proceeding.
6. **Flatten** using `scripts/flatten.py` with the confirmed interpretation.
7. **Validate** using `scripts/validate.py`. All four checks run by default — base reconciliation, percentage sums, NET integrity, completeness.
8. **Write outputs** — CSV and Excel of the flat file, plus the data dictionary and validation report.
9. **Summarise to the analyst** — what was produced, which validation checks passed/failed, where the files are.

## Output schema

The flat file has the following columns (see `reference/output-schema.md` for full specification):

- `source_sheet` — sheet name in the original file
- `question_id` — auto-generated if absent (Q1, Q2...)
- `question_text` — verbatim from the source
- `row_type` — one of: `response`, `net`, `subtotal`, `mean`, `median`
- `response_option` — the row label
- `banner_group` — the banner group name (Total, Gender, Age, Market...)
- `banner_value` — the specific cut (Total, Male, Female, 18-24...)
- `value` — the numeric value (stripped of sig markers if requested)
- `value_type` — `percent`, `mean`, `count`
- `base_n` — base size for this banner value
- `sig_markers` — present only if analyst requested preservation

Long format has one row per (question × response × banner_group × banner_value). Wide format pivots banner values to columns.

## Companion artefacts

Every run produces three files in the output folder:

- **Flat file** — `flat_<inputname>.csv` and `flat_<inputname>.xlsx`
- **Data dictionary** — `dictionary_<inputname>.csv` — column names, types, allowed values, notes
- **Validation report** — `validation_<inputname>.md` — human-readable summary of all four checks with any flagged issues

## Validation checks

All four run by default. Failures are flagged, not blocking — the analyst decides whether a flag prevents downstream analysis.

1. **Base reconciliation** — every banner value's `base_n` matches the banner plan
2. **Percentage check** — values within each question × banner cut sum to 100 (±1%) for percentage rows
3. **NET integrity** — NET rows are ≥ the sum of their component response rows within the same question
4. **Completeness** — every question and banner cut in the banner plan appears in the output

See `reference/validation-spec.md` for thresholds and edge cases.

## Non-negotiable rules

- **No template memory.** Every invocation is a fresh inspection. Never silently reuse assumptions from a prior run — agency templates shift more than analysts expect.
- **Always confirm before flattening.** Show the proposed interpretation to the analyst. Wait for explicit confirmation. Do not proceed on ambiguity.
- **Python moves the data.** The LLM must not transcribe cell values directly. All data movement happens through the scripts.
- **Preserve traceability.** Every output row must be traceable back to its source sheet and cell.
- **Flag, don't block.** If a validation check fails, write the output anyway and flag the issue clearly in the report. The analyst decides what to do with it.

## Dependencies

The scripts require:

- Python 3.10+
- `pandas`
- `openpyxl` (for .xlsx)
- `xlrd` (for .xls, optional)

Install if missing:

```bash
pip install pandas openpyxl xlrd --break-system-packages
```
