# flatten-crosstab

A Claude Code skill for converting agency crosstabs into flat, self-describing data for LLM-assisted quantitative analysis.

## Install

Drop this entire folder into your Claude Code skills directory. The skill auto-loads based on `SKILL.md`.

```bash
# Example — adjust to your Claude Code setup
cp -r flatten-crosstab ~/.claude/skills/
```

## Invoke

In Claude Code, either:

```
/flatten-crosstab
```

Or say it naturally:

> "flatten this crosstab"
> "convert this banner table to flat format"
> "tidy this DP output"

The skill will guide you through the rest.

## What it does

Takes a crosstab file (XLSX / XLS / CSV) and produces:

- `flat_<name>_long.csv` + `.xlsx` — one row per cell, self-describing
- `flat_<name>_wide.csv` + `.xlsx` — banner cuts as columns (optional)
- `dictionary_<name>.csv` — data dictionary for the flat output
- `validation_<name>.md` — human-readable report of all four checks

## Workflow

1. You share the crosstab file.
2. Claude Code asks for the banner plan, base definitions, and weighting note (whatever you have).
3. Claude Code inspects the file and proposes how it reads the structure.
4. You confirm or correct.
5. Python flattens the data deterministically.
6. Validation runs automatically — base reconciliation, percentage sums, NET integrity, completeness.
7. You get a clean summary with any flagged issues.

## What to have ready

- The crosstab file(s)
- A banner plan (ideally as a CSV with columns `banner_group`, `banner_value`, `base_n`)
- Base definitions (Total = all respondents? screened-in only?)
- Any weighting notes

## Non-negotiables

- Every run is a fresh inspection. No cached templates.
- Python moves the data. The LLM never transcribes cell values.
- Every output row traces back to its source sheet and cell.
- Validation failures are flagged, not blocking. You decide what to do.

## Limitations

- Not for raw respondent-level data. Use a separate skill for that.
- NET composition is inferred heuristically — check the validation report for false positives.
- Multi-response questions are auto-detected from question text; confirm during inspection if yours use non-standard phrasing.
- Template memory is intentionally disabled — if you want to reuse a config, save the run config JSON and pass it to `flatten.py` directly.

## Files in this folder

```
flatten-crosstab/
├── SKILL.md                          # Skill trigger + workflow (read by Claude Code)
├── README.md                         # This file
├── reference/
│   ├── workflow.md                   # Step-by-step interaction script
│   ├── output-schema.md              # Flat file column specification
│   ├── validation-spec.md            # Validation check definitions
│   ├── run_config.example.json       # Sample run config
│   └── banner_plan.example.csv       # Sample banner plan
└── scripts/
    ├── inspect_crosstab.py           # Inspects the file, proposes interpretation
    ├── flatten.py                    # Deterministic flattening (the core)
    └── validate.py                   # Runs the four checks, writes report
```

## Feedback

This is a working draft. If it held up for your study, say so. If it broke, tell me where — ideally with a sanitised snippet of the crosstab that tripped it.
