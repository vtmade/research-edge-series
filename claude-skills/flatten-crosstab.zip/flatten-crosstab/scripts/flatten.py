#!/usr/bin/env python3
"""
flatten.py

Deterministically flattens a crosstab file into the long/wide format specified
in reference/output-schema.md. Accepts a configuration JSON describing the
file's structure (produced by inspect + analyst confirmation) and writes the
flat output + data dictionary to disk.

Usage:
    python flatten.py --input <file> --config <json> --output-dir <dir> [--shape long|wide|both]
"""

import argparse
import json
import re
import sys
from pathlib import Path

import pandas as pd


# ---------- Helpers ----------

NET_PATTERNS = [r"^\s*NET\b", r"^\s*NETS?\s*[:\-]"]
SUBTOTAL_PATTERNS = [r"^\s*SUBTOTAL", r"^\s*SUB\s*TOTAL", r"^\s*TOTAL\s*$"]
MEAN_PATTERNS = [r"^\s*MEAN\b", r"^\s*AVERAGE\b", r"^\s*AVG\b", r"\bMEAN SCORE\b"]
MEDIAN_PATTERNS = [r"^\s*MEDIAN\b"]


def classify_row_type(label: str) -> str:
    """Classify a row based on its label."""
    if not isinstance(label, str):
        return "response"
    text = label.strip().upper()
    for p in NET_PATTERNS:
        if re.search(p, text):
            return "net"
    for p in SUBTOTAL_PATTERNS:
        if re.search(p, text):
            return "subtotal"
    for p in MEAN_PATTERNS:
        if re.search(p, text):
            return "mean"
    for p in MEDIAN_PATTERNS:
        if re.search(p, text):
            return "median"
    return "response"


def parse_value(raw, sig_handling: str):
    """
    Parse a cell value. Returns (value, sig_markers).
    sig_handling: 'strip' | 'preserve' | 'inline'
    """
    if raw is None or (isinstance(raw, float) and pd.isna(raw)):
        return None, None
    if isinstance(raw, (int, float)):
        return float(raw), None
    s = str(raw).strip()
    if s in ("", "-", "*", "N/A", "n/a", "NA"):
        return None, None
    # Match: optional minus, number, optional %, optional sig letters
    m = re.match(r"^\s*(-?\d+(?:\.\d+)?)\s*%?\s*([A-Za-z]{1,4})?\s*$", s)
    if m:
        val = float(m.group(1))
        sig = m.group(2) if m.group(2) else None
        if sig_handling == "inline":
            return s, None  # keep as-is
        return val, sig
    # Fallback: try a direct float cast
    try:
        return float(s.replace("%", "").strip()), None
    except ValueError:
        return None, None


def detect_value_type(label: str) -> str:
    """Guess value_type from the row label."""
    if not isinstance(label, str):
        return "percent"
    t = label.strip().upper()
    if any(re.search(p, t) for p in MEAN_PATTERNS):
        return "mean"
    if any(re.search(p, t) for p in MEDIAN_PATTERNS):
        return "mean"  # stored as numeric; median labelled via row_type
    return "percent"


def is_question_row(label: str, prev_was_response: bool) -> bool:
    """
    Heuristic: a row is a question if it's a long string (>30 chars) or starts
    with Q-number pattern. Also true if the previous row was blank and this
    row has content.
    """
    if not isinstance(label, str):
        return False
    s = label.strip()
    if not s:
        return False
    if len(s) > 30:
        return True
    if re.match(r"^Q\d+", s, re.IGNORECASE):
        return True
    if re.match(r"^\d+\.\s", s):
        return True
    return False


# ---------- Core flattening ----------

def flatten_sheet(
    df: pd.DataFrame,
    sheet_name: str,
    config: dict,
    sig_handling: str,
) -> pd.DataFrame:
    """Flatten a single sheet using the provided config."""
    banner_group_row = config.get("banner_group_row", 0)
    banner_value_row = config.get("banner_value_row", 1)
    base_size_row = config.get("base_size_row")
    question_col = config.get("question_column", 0)
    data_start_row = config.get("data_start_row", banner_value_row + 1)
    if base_size_row is not None and base_size_row >= data_start_row:
        data_start_row = base_size_row + 1

    # Build banner map: col_index -> (banner_group, banner_value, base_n)
    banner_map = {}
    group_row_raw = df.iloc[banner_group_row] if banner_group_row < len(df) else pd.Series()
    value_row_raw = df.iloc[banner_value_row] if banner_value_row < len(df) else pd.Series()
    base_row_raw = (
        df.iloc[base_size_row] if base_size_row is not None and base_size_row < len(df) else pd.Series()
    )

    # Forward-fill banner group across columns (for merged cells that pandas reads as NaN)
    current_group = "Total"
    for col in range(len(df.columns)):
        if col == question_col:
            continue
        group_val = group_row_raw.iloc[col] if col < len(group_row_raw) else None
        if pd.notna(group_val) and str(group_val).strip():
            current_group = str(group_val).strip()
        banner_value = value_row_raw.iloc[col] if col < len(value_row_raw) else None
        if pd.isna(banner_value) or not str(banner_value).strip():
            continue
        banner_value = str(banner_value).strip()

        base_n = None
        if len(base_row_raw) > col:
            base_raw = base_row_raw.iloc[col]
            if pd.notna(base_raw):
                if isinstance(base_raw, (int, float)):
                    base_n = int(base_raw)
                else:
                    m = re.search(r"(\d+)", str(base_raw))
                    if m:
                        base_n = int(m.group(1))

        banner_map[col] = {
            "banner_group": current_group,
            "banner_value": banner_value,
            "base_n": base_n,
        }

    # Walk data rows, forward-filling question text
    rows_out = []
    current_question_text = None
    current_question_id = None
    q_counter = 0

    for row_idx in range(data_start_row, len(df)):
        row = df.iloc[row_idx]
        label_raw = row.iloc[question_col] if question_col < len(row) else None
        if pd.isna(label_raw):
            continue
        label = str(label_raw).strip()
        if not label:
            continue

        # Is this a new question?
        if is_question_row(label, prev_was_response=False):
            current_question_text = label
            # Extract Q-id if present; otherwise auto-number
            m = re.match(r"^(Q\d+[a-z]?)", label, re.IGNORECASE)
            if m:
                current_question_id = m.group(1).upper()
            else:
                q_counter += 1
                current_question_id = f"Q{q_counter}"
            continue

        # Otherwise treat as a response row
        if current_question_text is None:
            # Response row before any question detected — skip with no-op
            continue

        row_type = classify_row_type(label)
        value_type = detect_value_type(label)

        for col, banner_info in banner_map.items():
            if col >= len(row):
                continue
            cell = row.iloc[col]
            value, sig = parse_value(cell, sig_handling)
            if value is None and sig is None:
                continue  # skip fully empty cells

            rows_out.append(
                {
                    "source_sheet": sheet_name,
                    "question_id": current_question_id,
                    "question_text": current_question_text,
                    "row_type": row_type,
                    "response_option": label,
                    "banner_group": banner_info["banner_group"],
                    "banner_value": banner_info["banner_value"],
                    "value": value,
                    "value_type": value_type,
                    "base_n": banner_info["base_n"],
                    "sig_markers": sig if sig_handling == "preserve" else None,
                }
            )

    return pd.DataFrame(rows_out)


def pivot_to_wide(long_df: pd.DataFrame) -> pd.DataFrame:
    """Convert long format to wide format."""
    if long_df.empty:
        return long_df
    # Build composite column name: banner_group_banner_value
    long_df = long_df.copy()
    long_df["banner_col"] = long_df["banner_group"] + "_" + long_df["banner_value"]

    index_cols = [
        "source_sheet",
        "question_id",
        "question_text",
        "row_type",
        "response_option",
        "value_type",
    ]
    wide = long_df.pivot_table(
        index=index_cols,
        columns="banner_col",
        values="value",
        aggfunc="first",
    ).reset_index()

    # Add base_n columns per banner cut
    base_df = (
        long_df[["banner_col", "base_n"]]
        .drop_duplicates()
        .set_index("banner_col")["base_n"]
    )
    for col in base_df.index:
        wide[f"{col}_base_n"] = base_df[col]

    return wide


def build_data_dictionary(df: pd.DataFrame) -> pd.DataFrame:
    """Build a data dictionary for the flat output."""
    rows = []
    descriptions = {
        "source_sheet": ("string", "Sheet name in the original file", "Any string"),
        "question_id": ("string", "Question identifier (auto-generated if absent)", "Q1, Q2, ..."),
        "question_text": ("string", "Verbatim question text from source", "Any string"),
        "row_type": (
            "string",
            "Classification of the row",
            "response | net | subtotal | mean | median",
        ),
        "response_option": ("string", "Row label (response option or NET/mean)", "Any string"),
        "banner_group": ("string", "Banner group name", "Total, Gender, Age, Market, ..."),
        "banner_value": ("string", "Specific cut within the banner group", "Total, Male, 18-24, ..."),
        "value": ("float", "Numeric value", "Stripped of sig markers if requested"),
        "value_type": ("string", "Kind of measure in value", "percent | mean | count"),
        "base_n": ("integer", "Base size for this banner value", "From banner plan; may be null"),
        "sig_markers": ("string", "Significance letters if preserved", "Null unless preservation requested"),
    }
    for col in df.columns:
        if col in descriptions:
            t, d, a = descriptions[col]
            rows.append({"column_name": col, "type": t, "description": d, "allowed_values": a, "notes": ""})
        else:
            # wide-format banner columns
            rows.append(
                {
                    "column_name": col,
                    "type": "float" if col.endswith("_base_n") is False else "integer",
                    "description": "Wide-format banner cut value" if not col.endswith("_base_n") else "Base size for banner cut",
                    "allowed_values": "Numeric",
                    "notes": "",
                }
            )
    return pd.DataFrame(rows)


# ---------- Main ----------

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="Path to crosstab file")
    parser.add_argument("--config", required=True, help="Path to run config JSON")
    parser.add_argument("--output-dir", required=True, help="Output directory")
    parser.add_argument(
        "--shape",
        default="long",
        choices=["long", "wide", "both"],
        help="Output shape (default: long)",
    )
    parser.add_argument(
        "--sig-handling",
        default="strip",
        choices=["strip", "preserve", "inline"],
        help="How to handle significance markers",
    )
    args = parser.parse_args()

    input_path = Path(args.input)
    config_path = Path(args.config)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    with open(config_path) as f:
        config = json.load(f)

    # Read all sheets
    all_long = []
    if input_path.suffix.lower() in [".xlsx", ".xls"]:
        xl = pd.ExcelFile(input_path)
        for sheet_name in xl.sheet_names:
            # Allow per-sheet config override
            sheet_config = config.get("sheets", {}).get(sheet_name, config.get("default", {}))
            df = pd.read_excel(input_path, sheet_name=sheet_name, header=None)
            long_df = flatten_sheet(df, sheet_name, sheet_config, args.sig_handling)
            if not long_df.empty:
                all_long.append(long_df)
    elif input_path.suffix.lower() == ".csv":
        df = pd.read_csv(input_path, header=None)
        long_df = flatten_sheet(df, "csv", config.get("default", {}), args.sig_handling)
        if not long_df.empty:
            all_long.append(long_df)
    else:
        print(f"ERROR: Unsupported file type: {input_path.suffix}", file=sys.stderr)
        sys.exit(1)

    if not all_long:
        print("ERROR: No data flattened. Check the config and file structure.", file=sys.stderr)
        sys.exit(1)

    consolidated = pd.concat(all_long, ignore_index=True)

    stem = input_path.stem
    outputs = {}

    # Write long format
    if args.shape in ("long", "both"):
        long_csv = output_dir / f"flat_{stem}_long.csv"
        long_xlsx = output_dir / f"flat_{stem}_long.xlsx"
        consolidated.to_csv(long_csv, index=False, encoding="utf-8-sig")
        consolidated.to_excel(long_xlsx, index=False)
        outputs["long_csv"] = str(long_csv)
        outputs["long_xlsx"] = str(long_xlsx)

    # Write wide format
    if args.shape in ("wide", "both"):
        wide_df = pivot_to_wide(consolidated)
        wide_csv = output_dir / f"flat_{stem}_wide.csv"
        wide_xlsx = output_dir / f"flat_{stem}_wide.xlsx"
        wide_df.to_csv(wide_csv, index=False, encoding="utf-8-sig")
        wide_df.to_excel(wide_xlsx, index=False)
        outputs["wide_csv"] = str(wide_csv)
        outputs["wide_xlsx"] = str(wide_xlsx)

    # Write data dictionary (based on long format since it has all canonical columns)
    dict_df = build_data_dictionary(consolidated)
    dict_csv = output_dir / f"dictionary_{stem}.csv"
    dict_df.to_csv(dict_csv, index=False, encoding="utf-8-sig")
    outputs["dictionary"] = str(dict_csv)

    summary = {
        "rows_written": len(consolidated),
        "unique_questions": consolidated["question_id"].nunique(),
        "unique_banner_groups": consolidated["banner_group"].nunique(),
        "unique_banner_values": consolidated["banner_value"].nunique(),
        "outputs": outputs,
    }
    print(json.dumps(summary, indent=2, default=str))


if __name__ == "__main__":
    main()
