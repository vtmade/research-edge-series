#!/usr/bin/env python3
"""
validate.py

Runs all four validation checks against a flat file and writes a human-readable
markdown report.

Usage:
    python validate.py --flat <flat.csv> [--banner-plan <banner_plan.csv>] --output <report.md>
"""

import argparse
import json
from datetime import datetime
from pathlib import Path

import pandas as pd


MULTI_RESPONSE_KEYWORDS = [
    "select all",
    "multiple",
    "any of",
    "all that apply",
    "more than one",
]


def is_multi_response(question_text: str) -> bool:
    if not isinstance(question_text, str):
        return False
    t = question_text.lower()
    return any(k in t for k in MULTI_RESPONSE_KEYWORDS)


def check_base_reconciliation(flat: pd.DataFrame, banner_plan: pd.DataFrame | None) -> dict:
    """Check 1: banner values' base_n matches the banner plan."""
    result = {"name": "Base reconciliation", "status": "passed", "issues": []}
    if banner_plan is None:
        result["status"] = "skipped"
        result["issues"].append("No banner plan provided — check skipped.")
        return result

    actual = (
        flat[["banner_group", "banner_value", "base_n"]]
        .drop_duplicates()
        .dropna(subset=["base_n"])
    )

    expected = banner_plan[["banner_group", "banner_value", "base_n"]].copy()
    expected["base_n"] = expected["base_n"].astype("Int64")

    merged = actual.merge(
        expected,
        on=["banner_group", "banner_value"],
        how="outer",
        suffixes=("_actual", "_expected"),
        indicator=True,
    )

    for _, row in merged.iterrows():
        if row["_merge"] == "left_only":
            result["issues"].append(
                {
                    "severity": "medium",
                    "detail": f"{row['banner_group']} × {row['banner_value']}: in file but not in banner plan (n={row['base_n_actual']})",
                }
            )
        elif row["_merge"] == "right_only":
            result["issues"].append(
                {
                    "severity": "high",
                    "detail": f"{row['banner_group']} × {row['banner_value']}: in banner plan (expected n={row['base_n_expected']}) but missing from file",
                }
            )
        else:
            if pd.notna(row["base_n_actual"]) and pd.notna(row["base_n_expected"]):
                if int(row["base_n_actual"]) != int(row["base_n_expected"]):
                    result["issues"].append(
                        {
                            "severity": "medium",
                            "detail": (
                                f"{row['banner_group']} × {row['banner_value']}: "
                                f"expected n={row['base_n_expected']}, got n={row['base_n_actual']}"
                            ),
                        }
                    )

    if result["issues"]:
        severities = {i["severity"] for i in result["issues"] if isinstance(i, dict)}
        if "high" in severities:
            result["status"] = "failed"
        else:
            result["status"] = "flagged"
    return result


def check_percentage_sums(flat: pd.DataFrame) -> dict:
    """Check 2: percentages within each question × banner cut sum to 100 (±1)."""
    result = {"name": "Percentage sum check", "status": "passed", "issues": []}

    pct = flat[(flat["value_type"] == "percent") & (flat["row_type"] == "response")].copy()
    if pct.empty:
        result["status"] = "skipped"
        result["issues"].append("No percentage response rows found.")
        return result

    groups = pct.groupby(
        ["question_id", "question_text", "banner_group", "banner_value"]
    )
    for (qid, qtext, bgroup, bvalue), group in groups:
        if is_multi_response(qtext):
            continue  # skip multi-response
        if group["value"].isna().any():
            result["issues"].append(
                {
                    "severity": "low",
                    "detail": f"{qid} × {bgroup} × {bvalue}: nulls present — sum check skipped",
                }
            )
            continue
        total = group["value"].sum()
        if not (99 <= total <= 101):
            severity = "medium" if 95 <= total <= 105 else "high"
            result["issues"].append(
                {
                    "severity": severity,
                    "detail": f"{qid} × {bgroup} × {bvalue}: sum = {total:.1f} (outside 100 ±1)",
                }
            )

    if result["issues"]:
        severities = {i["severity"] for i in result["issues"] if isinstance(i, dict)}
        if "high" in severities:
            result["status"] = "failed"
        else:
            result["status"] = "flagged"
    return result


def check_net_integrity(flat: pd.DataFrame) -> dict:
    """Check 3: NET rows are ≥ sum of component response rows."""
    result = {"name": "NET integrity", "status": "passed", "issues": []}

    has_nets = (flat["row_type"] == "net").any()
    if not has_nets:
        result["status"] = "skipped"
        result["issues"].append("No NET rows detected — check skipped.")
        return result

    # For each question × banner cut, compare NET(s) to sum of response rows.
    # NET composition is inferred as: all response rows within the same
    # question × banner cut. This is imperfect — flag as "composition inferred".
    groups = flat.groupby(["question_id", "banner_group", "banner_value"])
    for (qid, bgroup, bvalue), g in groups:
        nets = g[g["row_type"] == "net"]
        responses = g[g["row_type"] == "response"]
        if nets.empty or responses.empty:
            continue
        if responses["value"].isna().any():
            continue
        response_sum = responses["value"].sum()
        for _, net_row in nets.iterrows():
            if pd.isna(net_row["value"]):
                continue
            if net_row["value"] + 1 < response_sum:
                result["issues"].append(
                    {
                        "severity": "medium",
                        "detail": (
                            f"{qid} × {bgroup} × {bvalue}: NET '{net_row['response_option']}' "
                            f"= {net_row['value']:.1f}, but response sum = {response_sum:.1f} "
                            f"(NET composition inferred — may be a false positive)"
                        ),
                    }
                )

    if result["issues"]:
        result["status"] = "flagged"
    return result


def check_completeness(flat: pd.DataFrame, banner_plan: pd.DataFrame | None) -> dict:
    """Check 4: every question × banner cut in the plan appears in the output."""
    result = {"name": "Completeness", "status": "passed", "issues": []}
    if banner_plan is None:
        result["status"] = "skipped"
        result["issues"].append("No banner plan provided — check skipped.")
        return result

    # Expected set: (banner_group, banner_value) combinations from plan × all questions in flat
    expected_banners = set(
        zip(banner_plan["banner_group"], banner_plan["banner_value"])
    )
    actual_banners = set(zip(flat["banner_group"], flat["banner_value"]))

    missing_from_output = expected_banners - actual_banners
    extra_in_output = actual_banners - expected_banners

    for bg, bv in sorted(missing_from_output):
        result["issues"].append(
            {
                "severity": "high",
                "detail": f"Missing from output: {bg} × {bv}",
            }
        )
    for bg, bv in sorted(extra_in_output):
        result["issues"].append(
            {
                "severity": "medium",
                "detail": f"Present in output but not in banner plan: {bg} × {bv}",
            }
        )

    if result["issues"]:
        severities = {i["severity"] for i in result["issues"] if isinstance(i, dict)}
        if "high" in severities:
            result["status"] = "failed"
        else:
            result["status"] = "flagged"
    return result


# ---------- Report ----------

STATUS_ICON = {
    "passed": "✅",
    "flagged": "⚠️",
    "failed": "❌",
    "skipped": "⏭️",
}


def write_report(
    flat_path: Path,
    banner_plan_path: Path | None,
    flat: pd.DataFrame,
    checks: list[dict],
    output_path: Path,
):
    lines = []
    lines.append(f"# Validation report — {flat_path.name}")
    lines.append("")
    lines.append(f"Run at: {datetime.now().isoformat(timespec='seconds')}")
    lines.append(f"Flat file: `{flat_path}`")
    lines.append(
        f"Banner plan: `{banner_plan_path}`"
        if banner_plan_path
        else "Banner plan: not provided"
    )
    lines.append("")
    lines.append("---")
    lines.append("")

    for check in checks:
        icon = STATUS_ICON.get(check["status"], "❓")
        lines.append(f"## {check['name']}")
        lines.append("")
        lines.append(f"Status: {icon} {check['status'].title()}")
        lines.append("")
        if not check["issues"]:
            lines.append("No issues.")
        else:
            for issue in check["issues"]:
                if isinstance(issue, dict):
                    lines.append(
                        f"- **{issue['severity'].upper()}** — {issue['detail']}"
                    )
                else:
                    lines.append(f"- {issue}")
        lines.append("")
        lines.append("---")
        lines.append("")

    # Summary
    lines.append("## Summary")
    lines.append("")
    lines.append(f"- Total rows in flat file: {len(flat):,}")
    lines.append(f"- Unique questions: {flat['question_id'].nunique()}")
    lines.append(f"- Unique banner groups: {flat['banner_group'].nunique()}")
    lines.append(f"- Unique banner values: {flat['banner_value'].nunique()}")
    lines.append("")

    all_statuses = [c["status"] for c in checks]
    if "failed" in all_statuses:
        overall = "❌ One or more checks failed. Review before proceeding."
    elif "flagged" in all_statuses:
        overall = "⚠️ Checks flagged issues. Review before proceeding."
    elif all(s in ("passed", "skipped") for s in all_statuses):
        overall = "✅ All executed checks passed."
    else:
        overall = "❓ Mixed results."
    lines.append(f"**Overall: {overall}**")
    lines.append("")

    output_path.write_text("\n".join(lines), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--flat", required=True, help="Path to flat CSV file")
    parser.add_argument("--banner-plan", default=None, help="Path to banner plan CSV (optional)")
    parser.add_argument("--output", required=True, help="Path to write markdown report")
    args = parser.parse_args()

    flat_path = Path(args.flat)
    flat = pd.read_csv(flat_path)

    banner_plan = None
    banner_plan_path = None
    if args.banner_plan:
        banner_plan_path = Path(args.banner_plan)
        banner_plan = pd.read_csv(banner_plan_path)
        required_cols = {"banner_group", "banner_value", "base_n"}
        missing = required_cols - set(banner_plan.columns)
        if missing:
            print(f"ERROR: banner plan missing columns: {missing}")
            banner_plan = None

    checks = [
        check_base_reconciliation(flat, banner_plan),
        check_percentage_sums(flat),
        check_net_integrity(flat),
        check_completeness(flat, banner_plan),
    ]

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    write_report(flat_path, banner_plan_path, flat, checks, output_path)

    summary = {
        "report": str(output_path),
        "statuses": {c["name"]: c["status"] for c in checks},
        "total_issues": sum(len(c["issues"]) for c in checks),
    }
    print(json.dumps(summary, indent=2, default=str))


if __name__ == "__main__":
    main()
