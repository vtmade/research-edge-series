#!/usr/bin/env python3
"""
inspect_crosstab.py

Reads a crosstab file (XLSX/XLS/CSV) and returns a structured summary of its
layout for the LLM to present to the analyst for confirmation.

Output is JSON printed to stdout, designed to be parsed by Claude Code.

Usage:
    python inspect_crosstab.py <path_to_file>
"""

import sys
import json
import re
from pathlib import Path

import pandas as pd


def inspect_sheet(df: pd.DataFrame, sheet_name: str) -> dict:
    """Inspect a single sheet and propose its structure."""
    result = {
        "sheet_name": sheet_name,
        "dimensions": {"rows": len(df), "cols": len(df.columns)},
        "banner_rows_candidate": [],
        "question_column_candidate": None,
        "sample_questions": [],
        "sample_response_options": [],
        "base_size_row_candidate": None,
        "ambiguities": [],
        "row_type_markers_found": {
            "net": False,
            "subtotal": False,
            "mean": False,
            "median": False,
        },
        "sig_markers_detected": False,
    }

    if df.empty:
        result["ambiguities"].append("Sheet is empty.")
        return result

    # Find banner row candidates: first 5 rows, looking for rows with mostly
    # short string values (banner labels are typically short).
    for row_idx in range(min(5, len(df))):
        row = df.iloc[row_idx]
        non_null = row.dropna()
        if len(non_null) == 0:
            continue
        string_ratio = sum(isinstance(v, str) for v in non_null) / len(non_null)
        avg_str_len = (
            sum(len(str(v)) for v in non_null) / len(non_null) if len(non_null) else 0
        )
        if string_ratio > 0.7 and avg_str_len < 25:
            result["banner_rows_candidate"].append(
                {
                    "row_index": row_idx,
                    "sample_values": [str(v) for v in non_null.head(8).tolist()],
                }
            )

    # Find question column: typically column 0, look for long strings mixed
    # with shorter strings (questions + response options).
    if len(df.columns) > 0:
        col0 = df.iloc[:, 0].dropna()
        if len(col0) > 0:
            string_ratio = sum(isinstance(v, str) for v in col0) / len(col0)
            if string_ratio > 0.6:
                result["question_column_candidate"] = 0

    # Sample questions and response options from column 0
    if result["question_column_candidate"] is not None:
        col0_values = df.iloc[:, 0].dropna().astype(str).tolist()
        # Heuristic: questions are longer strings (>30 chars) or start with "Q"
        questions = [
            v for v in col0_values
            if len(v) > 30 or re.match(r"^Q\d+[\.\:\s]", v, re.IGNORECASE)
        ]
        responses = [v for v in col0_values if 0 < len(v) <= 30 and v not in questions]
        result["sample_questions"] = questions[:10]
        result["sample_response_options"] = list(set(responses))[:15]

    # Detect row type markers
    col0_str = " ".join(df.iloc[:, 0].dropna().astype(str).tolist()).upper()
    result["row_type_markers_found"]["net"] = "NET " in col0_str or "NET:" in col0_str
    result["row_type_markers_found"]["subtotal"] = "SUBTOTAL" in col0_str or "SUB TOTAL" in col0_str
    result["row_type_markers_found"]["mean"] = bool(
        re.search(r"\bMEAN\b|\bAVERAGE\b|\bAVG\b", col0_str)
    )
    result["row_type_markers_found"]["median"] = "MEDIAN" in col0_str

    # Detect base size row: look in first 5 rows for a row with mostly numeric
    # values or "(n=...)" patterns
    for row_idx in range(min(5, len(df))):
        row = df.iloc[row_idx].dropna()
        if len(row) == 0:
            continue
        row_str = " ".join(str(v) for v in row)
        if re.search(r"n\s*=\s*\d+", row_str, re.IGNORECASE):
            result["base_size_row_candidate"] = row_idx
            break
        # Also check: row of mostly integers in banner range
        numeric_count = sum(
            1 for v in row
            if isinstance(v, (int, float)) and not pd.isna(v) and v > 20
        )
        if numeric_count >= len(row) * 0.7:
            result["base_size_row_candidate"] = row_idx
            break

    # Detect sig markers: scan sample cells for trailing uppercase letters
    # on numeric-looking values
    sample_cells = df.iloc[:30, :].values.flatten()
    for cell in sample_cells:
        if isinstance(cell, str):
            if re.search(r"\d+\s*[A-Za-z]{1,3}$", cell.strip()):
                result["sig_markers_detected"] = True
                break

    # Flag ambiguities
    if not result["banner_rows_candidate"]:
        result["ambiguities"].append(
            "Could not detect a banner row in the first 5 rows."
        )
    if result["question_column_candidate"] is None:
        result["ambiguities"].append(
            "Could not identify a clear question column."
        )
    if not result["sample_questions"]:
        result["ambiguities"].append(
            "No question-like rows detected. Input may not be a standard crosstab."
        )

    return result


def inspect_file(filepath: str) -> dict:
    """Inspect a full file (all sheets) and return a summary."""
    path = Path(filepath)
    if not path.exists():
        return {"error": f"File not found: {filepath}"}

    summary = {
        "file": str(path.absolute()),
        "file_size_kb": round(path.stat().st_size / 1024, 1),
        "extension": path.suffix.lower(),
        "sheets": [],
    }

    try:
        if path.suffix.lower() in [".xlsx", ".xls"]:
            xl = pd.ExcelFile(filepath)
            summary["sheet_count"] = len(xl.sheet_names)
            for sheet_name in xl.sheet_names:
                df = pd.read_excel(filepath, sheet_name=sheet_name, header=None)
                summary["sheets"].append(inspect_sheet(df, sheet_name))
        elif path.suffix.lower() == ".csv":
            df = pd.read_csv(filepath, header=None)
            summary["sheet_count"] = 1
            summary["sheets"].append(inspect_sheet(df, "csv"))
        else:
            summary["error"] = f"Unsupported file type: {path.suffix}"
    except Exception as e:
        summary["error"] = f"Failed to read file: {str(e)}"

    return summary


def main():
    if len(sys.argv) < 2:
        print(json.dumps({"error": "Usage: inspect_crosstab.py <path>"}))
        sys.exit(1)

    filepath = sys.argv[1]
    result = inspect_file(filepath)
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
