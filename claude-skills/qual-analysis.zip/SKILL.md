---
name: qual-analysis
description: Analyze unstructured qualitative text data — interview transcripts, focus group transcripts, Reddit threads, survey responses, and other text corpora — using rigorous qualitative research methods (thematic analysis, grounded theory coding, pattern recognition). Produces staged analytical JSON intermediates (not reports or summaries) for downstream consumption by humans or other AI systems. ONLY trigger when the user explicitly provides text data to analyze qualitatively (file paths, pasted text, or uses /qual-analysis). Do NOT auto-trigger on casual mentions of "qualitative", "interviews", "analysis", "transcripts", or general research requests. The user must be handing you data to process.
---

# Qualitative Text Analysis

Analyze unstructured qualitative text data through rigorous coding methodology. Produces **structured analytical data objects** — not reports, summaries, or insights. The user takes these outputs for downstream analysis or injection into other AI systems.

## Execution Mode: AUTOPILOT

Run all stages end-to-end without stopping for confirmation. Only pause to ask the user if:
1. The input type is genuinely ambiguous after reading the data
2. You encounter more than 100 documents (ask about batching strategy)

Otherwise: read, code, analyze, write all files, then present the summary.

---

## When Triggered: Read & Orient

1. **Read all input files** using the Read tool directly. For pasted text, write to a temp file first.
2. **Detect input type** from content:
   - **Interview** — 2 speakers alternating, one asks short questions, one gives long answers
   - **Focus group** — 3+ speakers with a moderator role, turn-taking, group dynamics
   - **Reddit CSV** — CSV with columns: Author, Score, Body, Type, Parent_Comment_Number
   - **Survey** — Tabular data with question columns and many short responses (median < 50 words)
   - **Generic text** — None of the above; segment by paragraph
3. **Identify participants** and their roles (interviewer/respondent, moderator/participant, author, anonymous respondent)
4. **Note data quality issues** — empty segments, very short segments, encoding problems, missing structure
5. If type is genuinely ambiguous, ask the user. Otherwise proceed with best detection.

---

## Stage 1: Code

Perform open coding on every segment following Braun & Clarke thematic analysis and grounded theory principles. This is the core analytical work.

### Coding unit by input type

| Input Type | Unit | Special Dimensions |
|------------|------|--------------------|
| Interview | Speaker turn | Prompted vs. volunteered |
| Focus group | Speaker exchange | Consensus level (agreement/disagreement/mixed) |
| Reddit | Single comment | Score, depth, type (comment/reply) |
| Survey | Single response | Question context, response length |
| Generic | Paragraph | Position in document |

### For each segment assign

- **Thematic code** — Hierarchical: `DOMAIN/CATEGORY/SUBCATEGORY`. Let codes emerge inductively from the data. Do NOT use a predetermined taxonomy. Three levels is typical.
- **In-vivo code** — Participant's own words when striking or analytically significant. Not every segment needs one.
- **Confidence** — `high` (clearly supported), `medium` (reasonable but ambiguous), `low` (best guess, unclear)
- **Coding notes** — Optional, only when context matters for interpretation

### Coding discipline

- Code what is said, not what you think it means. "Describes pricing as confusing" not "is frustrated with pricing"
- Be specific enough to cluster, general enough to group. `EXPERIENCE/ONBOARDING/FRICTION` not just `EXPERIENCE`
- When uncertain, code at the more specific level — you can merge up in analysis, splitting down later is harder
- Code everything including "boring" segments — they often become the most important negative cases
- Flag ambiguous cases with `confidence: low` rather than stopping to ask
- Do not skip segments. Do not pre-interpret. Do not summarize.
- If a segment contains multiple codeable ideas, assign multiple codes

### Output: `coding.json`

```json
{
  "_metadata": {
    "input_type": "...",
    "type_confidence": "high|medium|low",
    "document_count": 0,
    "segment_count": 0,
    "total_word_count": 0,
    "participant_count": 0,
    "unique_codes": 0,
    "total_codes": 0,
    "source_files": ["..."],
    "generated_at": "ISO timestamp"
  },
  "participants": [
    {
      "id": "P1",
      "label": "Speaker name",
      "role": "interviewer|respondent|moderator|participant|author",
      "segment_count": 0,
      "word_count": 0
    }
  ],
  "coded_segments": [
    {
      "segment_id": "seg_1",
      "document_id": "...",
      "speaker": "P1",
      "speaker_label": "...",
      "text": "verbatim text",
      "thematic_code": "DOMAIN/CATEGORY/SUBCATEGORY",
      "in_vivo_code": "participant's words or null",
      "confidence": "high|medium|low",
      "coding_notes": "optional"
    }
  ],
  "code_inventory": {
    "DOMAIN/CATEGORY/SUBCATEGORY": { "count": 0, "breadth": 0 }
  }
}
```

---

## Stage 2: Analyze

Build the analytical framework from the coded data. This stage produces themes, quotes, patterns, and cross-case analysis in a single pass.

### 2a. Thematic Framework

Group open codes into themes using axial coding:
- Each theme: name, definition, boundary (what it excludes), constituent codes, participant spread
- Inter-theme relationships: co-occurrence, causal, temporal, contradiction — with evidence
- Negative cases: codes that don't fit any theme, expected themes that are absent
- **Core category** (selective coding): single structural description of the dominant pattern integrating all themes. This is NOT an insight or recommendation — it is a structural description.

### 2b. Quote Library

For each theme, select 3-5 most powerful supporting quotes:
- Verbatim text exactly as it appears in the source — never paraphrase
- Context before/after (1-2 sentences for interpretability)
- Selection rationale and representativeness tag (`typical` or `outlier`)
- Include at least one counter-example or nuanced perspective per theme where possible

**Input-type-specific selection:**
- Focus groups: include quotes capturing group dynamics (agreement, disagreement, building on others)
- Reddit: include high-score AND low-score quotes for the same theme
- Surveys: prefer longer, more detailed responses
- Interviews: prefer unprompted/volunteered statements over prompted ones

### 2c. Pattern Analysis

Apply all 6 pattern types:

1. **Similarity** — What do participants share? Strongest when it crosses demographic/context lines.
2. **Difference** — What contrasts exist? Look for moderating factors that explain divergence.
3. **Frequency** — Distinguish **breadth** (how many participants) from **depth** (how often each mentions it). High breadth + high depth = dominant. Low breadth + high depth = niche but intense.
4. **Sequence** — What follows what? Journey stages, escalation, decision pathways, emotional arcs.
5. **Correspondence** — What co-occurs? Cross-tabulate themes x participants. Most valuable when the association is surprising.
6. **Causation** — What appears to drive what? ALWAYS label as `participant-reported` or `analyst-inferred`, never as established fact.

For each pattern: type, description, evidence (themes/codes), strength (strong/moderate/suggestive), participant spread.

### 2d. Cross-Case Analysis

- Build participant x theme matrix (rows = participants, columns = themes, cells = presence/intensity)
- Identify typologies ONLY if natural groupings emerge — do not force them
- Document outliers — participants who don't fit any pattern are often the most analytically valuable

**Input-type-specific analysis:**
- Focus groups: consensus vs. divergence per theme; distinguish genuine consensus (independent agreement, different language) from social pressure (echoing, minimal elaboration)
- Reddit: score distribution per theme = community endorsement (not truth); thread depth = engagement/controversy
- Surveys: prevalence percentages per theme
- Interviews: prompted vs. volunteered distinction

### 2e. Inline Quality Checks

While analyzing, verify:
- No orphan codes (codes not assigned to any theme) — if found, note them
- Every quote traces to a coded segment
- Coding consistency — similar segments coded similarly
- Note confidence distribution (% high/medium/low)

### Output: `analysis.json`

```json
{
  "_metadata": {
    "theme_count": 0,
    "total_quotes": 0,
    "pattern_count": 0,
    "overall_quality": "high|acceptable|needs_review",
    "confidence_distribution": { "high": 0, "medium": 0, "low": 0 },
    "generated_at": "ISO timestamp"
  },
  "themes": [
    {
      "theme_id": "T1",
      "name": "Clear descriptive name",
      "definition": "What this theme captures",
      "boundary": "What it explicitly excludes",
      "sub_themes": [],
      "constituent_codes": [],
      "code_count": 0,
      "segment_count": 0,
      "participant_spread": [],
      "participant_count": 0
    }
  ],
  "theme_relationships": [
    {
      "theme_a": "T1",
      "theme_b": "T2",
      "relationship_type": "co_occurrence|causal|temporal|contradiction",
      "label": "participant-reported|analyst-inferred",
      "description": "...",
      "evidence": "..."
    }
  ],
  "core_category": "Single structural description of the dominant pattern",
  "negative_cases": [
    { "description": "...", "implication": "..." }
  ],
  "quotes_by_theme": {
    "T1": [
      {
        "quote_id": "Q1",
        "theme_id": "T1",
        "segment_id": "seg_1",
        "speaker": "P1",
        "text": "verbatim quote",
        "context_before": "...",
        "context_after": "...",
        "representativeness": "typical|outlier",
        "selection_rationale": "..."
      }
    ]
  },
  "patterns": [
    {
      "pattern_id": "PAT1",
      "type": "similarity|difference|frequency|sequence|correspondence|causation",
      "description": "...",
      "evidence_themes": [],
      "strength": "strong|moderate|suggestive",
      "participant_spread": [],
      "notes": "..."
    }
  ],
  "cross_case_matrix": {
    "participants": [],
    "themes": [],
    "matrix": {
      "P1": { "T1": "high|medium|low|absent" }
    }
  },
  "typologies": [
    {
      "type_name": "Descriptive label",
      "participants": [],
      "characteristic_pattern": "..."
    }
  ],
  "frequency_tables": {
    "code_frequency": {},
    "theme_frequency": {}
  },
  "qc_notes": {
    "orphan_codes": [],
    "coding_inconsistencies": [],
    "low_confidence_items": []
  }
}
```

---

## Output: summary.md

After writing both JSON files, produce `summary.md` with:
- Input summary (type, documents, segments, participants)
- Coding summary (unique codes, code count, confidence distribution)
- Theme summary (theme count, largest/smallest themes, core category)
- Quote summary (quotes per theme, representativeness balance)
- Pattern summary (patterns by type, dominant patterns)
- Quality notes (overall rating, any issues flagged)
- File listing

Present the summary to the user along with the list of output files. This is the only point where you present results.

---

## Guardrails

### Data integrity
- Every coded value must trace to a specific text segment. No fabrication.
- Every quote must be verbatim from the source text. Never invent, paraphrase, or "clean up" quotes.
- Preserve the original text exactly — never translate, paraphrase, or modify participant language.
- Use `[...]` to mark any truncation.

### Interpretation discipline
- Distinguish **description** (what the data shows) from **interpretation** (what it might mean). This pipeline produces descriptions only.
- Do not add demographic assumptions not present in the data.
- Do not infer emotional states unless the participant explicitly states them or uses clearly emotional language.
- Label all causal claims as `participant-reported` or `analyst-inferred`.

### Coding pitfalls to avoid
- **Over-lumping**: `EXPERIENCE` when `EXPERIENCE/ONBOARDING/FRICTION` vs `EXPERIENCE/SUPPORT/RESOLUTION` are meaningfully different
- **Under-splitting**: 50+ unique codes likely contain synonyms — consolidate during axial coding
- **Ignoring boring segments**: Mundane, repeated segments often yield the strongest findings
- **Premature interpretation**: "Customer is frustrated" is interpretation; "customer describes pricing as confusing" is description
- **Forcing themes**: If a theme requires stretching to include enough codes, it may not exist
- **Ignoring negative cases**: The few who DON'T show a pattern are the most valuable for understanding what drives it
- **Context stripping**: "It was fine" means different things depending on what preceded it

### Anonymity
- Preserve whatever anonymity conventions the source data uses.
- Do not add identifying information not present in the source.

---

## Edge Cases

- **Small dataset** (<1000 words, 1-2 docs): Proceed but note limitations. Skip cross-case matrix if only 1 participant. Scale down — fewer codes, themes, patterns. Do not force structure onto thin data.
- **Large dataset** (50+ docs): Code in batches of 10-15 documents. After each batch, review code inventory for consistency before continuing. Merge code inventories between batches.
- **Non-English text**: Code in the original language. Provide English translations in parentheses where helpful.
- **No research question**: Proceed inductively. Note in metadata that analysis is exploratory.
- **Mixed input types**: Process each document with its appropriate heuristics. Note cross-format comparison in analysis.
- **Pasted text with no structure**: Write to temp file, detect type from content, segment by paragraph if no speakers found.

---

## JSON Formatting

- `ensure_ascii=False` — preserve all Unicode
- `indent=2` — human-readable
- Include `_metadata` with `generated_at` (ISO timestamp) in every output file
- All output files go to the user's current working directory or a subdirectory if specified
